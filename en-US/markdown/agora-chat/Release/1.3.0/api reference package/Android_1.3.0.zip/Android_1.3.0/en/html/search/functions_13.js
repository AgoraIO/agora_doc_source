var searchData=
[
  ['videomessagebody_0',['VideoMessageBody',['../classio_1_1agora_1_1chat_1_1_video_message_body.html#a9b85452c80001e090adffe5dfad5f66a',1,'io.agora.chat.VideoMessageBody.VideoMessageBody(String videoFilePath, String thumbPath, int duration, long filelength)'],['../classio_1_1agora_1_1chat_1_1_video_message_body.html#a8e30151631e8b6ed32eba9a71b89ab1d',1,'io.agora.chat.VideoMessageBody.VideoMessageBody(Uri videoFilePath, Uri thumbPath, int duration, long filelength)']]],
  ['voicemessagebody_1',['VoiceMessageBody',['../classio_1_1agora_1_1chat_1_1_voice_message_body.html#a3979eb927f0d1b35481c805185c010de',1,'io.agora.chat.VoiceMessageBody.VoiceMessageBody(File voiceFile, int duration)'],['../classio_1_1agora_1_1chat_1_1_voice_message_body.html#aef6383a2a1c24e71c191befa95a05855',1,'io.agora.chat.VoiceMessageBody.VoiceMessageBody(Uri voiceFile, int duration)']]]
];
