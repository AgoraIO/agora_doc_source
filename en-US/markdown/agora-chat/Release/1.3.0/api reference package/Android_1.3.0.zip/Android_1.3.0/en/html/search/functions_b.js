var searchData=
[
  ['markallconversationsasread_0',['markAllConversationsAsRead',['../classio_1_1agora_1_1chat_1_1_chat_manager.html#afc7d7583797e48258cab1a1d8dc38413',1,'io::agora::chat::ChatManager']]],
  ['markallmessagesasread_1',['markAllMessagesAsRead',['../classio_1_1agora_1_1chat_1_1_conversation.html#aa64a9865b7cb91b849a89cffa12f3111',1,'io::agora::chat::Conversation']]],
  ['markmessageasread_2',['markMessageAsRead',['../classio_1_1agora_1_1chat_1_1_conversation.html#a1e331be4eea4f59fb7d1f6c1da915b09',1,'io::agora::chat::Conversation']]],
  ['marks_3',['marks',['../classio_1_1agora_1_1chat_1_1_conversation.html#aa18f1c328d3ff73bf59aa867b01ba4e4',1,'io::agora::chat::Conversation']]],
  ['messagepininfo_4',['MessagePinInfo',['../classio_1_1agora_1_1chat_1_1_message_pin_info.html#afe33e1f0bfb5f2bbf08672dd242aca6f',1,'io.agora.chat.MessagePinInfo.MessagePinInfo()'],['../classio_1_1agora_1_1chat_1_1_message_pin_info.html#adfe4d8f6bd566a33a7eee8feefe59487',1,'io.agora.chat.MessagePinInfo.MessagePinInfo(EMAMessagePinInfo emaObject)']]],
  ['msgtype2conversationtype_5',['msgType2ConversationType',['../classio_1_1agora_1_1chat_1_1_conversation.html#acfe9c4c7af5ceea4916e8a689594ab40',1,'io::agora::chat::Conversation']]],
  ['muteallmembers_6',['muteAllMembers',['../classio_1_1agora_1_1chat_1_1_chat_room_manager.html#a51ad88a1ddb062b4f520da1292ef4b65',1,'io.agora.chat.ChatRoomManager.muteAllMembers()'],['../classio_1_1agora_1_1chat_1_1_group_manager.html#accfed3f68b3824886d1bdcb0287aa37b',1,'io.agora.chat.GroupManager.muteAllMembers()']]],
  ['mutechatroommembers_7',['muteChatRoomMembers',['../classio_1_1agora_1_1chat_1_1_chat_room_manager.html#a7d1cd99af7bfae190640ee9be1d1492d',1,'io::agora::chat::ChatRoomManager']]],
  ['mutegroupmembers_8',['muteGroupMembers',['../classio_1_1agora_1_1chat_1_1_group_manager.html#ad4fd626730680edaf188100320830436',1,'io::agora::chat::GroupManager']]]
];
