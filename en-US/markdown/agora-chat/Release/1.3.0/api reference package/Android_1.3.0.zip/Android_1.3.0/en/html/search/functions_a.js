var searchData=
[
  ['leavechatroom_0',['leaveChatRoom',['../classio_1_1agora_1_1chat_1_1_chat_room_manager.html#a4f2c430782206971480c73a49311b143',1,'io.agora.chat.ChatRoomManager.leaveChatRoom(final String roomId)'],['../classio_1_1agora_1_1chat_1_1_chat_room_manager.html#a6be50d9e4113b09273c0a5fd961e2a59',1,'io.agora.chat.ChatRoomManager.leaveChatRoom(final String roomId, CallBack callback)']]],
  ['leavechatthread_1',['leaveChatThread',['../classio_1_1agora_1_1chat_1_1_chat_thread_manager.html#a1ef302adb0ad7eaebfba17612478800b',1,'io::agora::chat::ChatThreadManager']]],
  ['leavegroup_2',['leaveGroup',['../classio_1_1agora_1_1chat_1_1_group_manager.html#a0f3b5c8b86df4674e3caaea28d4e8b98',1,'io::agora::chat::GroupManager']]],
  ['loadallconversations_3',['loadAllConversations',['../classio_1_1agora_1_1chat_1_1_chat_manager.html#a670d44662419ddee494710e881096c43',1,'io::agora::chat::ChatManager']]],
  ['loadallgroups_4',['loadAllGroups',['../classio_1_1agora_1_1chat_1_1_group_manager.html#ad4c307c7a9f9942945ce954c3938ff60',1,'io::agora::chat::GroupManager']]],
  ['loadmoremsgfromdb_5',['loadMoreMsgFromDB',['../classio_1_1agora_1_1chat_1_1_conversation.html#aa560e6de02d3bafe995ba21a7b1aa593',1,'io.agora.chat.Conversation.loadMoreMsgFromDB(String startMsgId, int pageSize)'],['../classio_1_1agora_1_1chat_1_1_conversation.html#ac2108743578b618079dc9e2a9cac791d',1,'io.agora.chat.Conversation.loadMoreMsgFromDB(String startMsgId, int pageSize, SearchDirection direction)']]],
  ['localtime_6',['localTime',['../classio_1_1agora_1_1chat_1_1_chat_message.html#a3209a5983a9d62e926384fc76ce35996',1,'io::agora::chat::ChatMessage']]],
  ['locationmessagebody_7',['LocationMessageBody',['../classio_1_1agora_1_1chat_1_1_location_message_body.html#a88115598ce7d271425327c91ce806361',1,'io::agora::chat::LocationMessageBody']]],
  ['login_8',['login',['../classio_1_1agora_1_1chat_1_1_chat_client.html#a81011619727d1a9b6663274f981465e2',1,'io::agora::chat::ChatClient']]],
  ['loginwithagoratoken_9',['loginWithAgoraToken',['../classio_1_1agora_1_1chat_1_1_chat_client.html#abb72e1e403e7e3f4ded23e8b4f460bd6',1,'io::agora::chat::ChatClient']]],
  ['loginwithtoken_10',['loginWithToken',['../classio_1_1agora_1_1chat_1_1_chat_client.html#ac2b19ffdcd879b5f239baacbaa09423b',1,'io::agora::chat::ChatClient']]],
  ['logout_11',['logout',['../classio_1_1agora_1_1chat_1_1_chat_client.html#a5716016495fc60a8c722a27bd47731d2',1,'io.agora.chat.ChatClient.logout(boolean unbindToken)'],['../classio_1_1agora_1_1chat_1_1_chat_client.html#a014e2abb85595417b64799dabfb8ac74',1,'io.agora.chat.ChatClient.logout(final boolean unbindToken, final CallBack callback)']]]
];
