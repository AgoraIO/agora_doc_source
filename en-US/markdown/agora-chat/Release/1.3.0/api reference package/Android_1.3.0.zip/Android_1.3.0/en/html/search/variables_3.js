var searchData=
[
  ['database_5ferror_0',['DATABASE_ERROR',['../classio_1_1agora_1_1_error.html#a6138561d9c5d4948bd3069242072987a',1,'io::agora::Error']]],
  ['discussiongroup_1',['DiscussionGroup',['../enumio_1_1agora_1_1chat_1_1_conversation_1_1_conversation_type.html#a4a7f55396459198513476544ea01dab8',1,'io::agora::chat::Conversation::ConversationType']]],
  ['down_2',['DOWN',['../enumio_1_1agora_1_1chat_1_1_conversation_1_1_search_direction.html#ac245786890f592f0990e6ff53ba76318',1,'io::agora::chat::Conversation::SearchDirection']]]
];
