var searchData=
[
  ['kickalldevices_0',['kickAllDevices',['../classio_1_1agora_1_1chat_1_1_chat_client.html#a10ea5e3515d553778c85890ff2e8caf3',1,'io::agora::chat::ChatClient']]],
  ['kickalldeviceswithtoken_1',['kickAllDevicesWithToken',['../classio_1_1agora_1_1chat_1_1_chat_client.html#a2f9eeab4b0bf16de141b6f242599cf40',1,'io::agora::chat::ChatClient']]],
  ['kickdevice_2',['kickDevice',['../classio_1_1agora_1_1chat_1_1_chat_client.html#a044520430eaa1935566f87d64ced9758',1,'io::agora::chat::ChatClient']]],
  ['kickdevicewithtoken_3',['kickDeviceWithToken',['../classio_1_1agora_1_1chat_1_1_chat_client.html#a9f2b22269ff7269ae8e40b7c50990086',1,'io::agora::chat::ChatClient']]]
];
