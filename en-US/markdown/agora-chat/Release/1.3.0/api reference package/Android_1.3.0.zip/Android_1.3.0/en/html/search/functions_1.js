var searchData=
[
  ['binddevicetoken_0',['bindDeviceToken',['../classio_1_1agora_1_1chat_1_1_push_manager.html#ab30d1b2bbbd72d9ad298aab8c7e394ea',1,'io::agora::chat::PushManager']]],
  ['blockchatroommembers_1',['blockChatroomMembers',['../classio_1_1agora_1_1chat_1_1_chat_room_manager.html#a73edbedeaa74a3707e6fceefe4b50d2b',1,'io::agora::chat::ChatRoomManager']]],
  ['blockgroupmessage_2',['blockGroupMessage',['../classio_1_1agora_1_1chat_1_1_group_manager.html#a3488560e515cc783c12d04f7b3377d99',1,'io::agora::chat::GroupManager']]],
  ['blockuser_3',['blockUser',['../classio_1_1agora_1_1chat_1_1_group_manager.html#aaa37498c8c6eb2e6d4bee059b6830606',1,'io::agora::chat::GroupManager']]],
  ['blockusers_4',['blockUsers',['../classio_1_1agora_1_1chat_1_1_group_manager.html#a30b37f13386fd7369e37377538f441dc',1,'io::agora::chat::GroupManager']]]
];
