var searchData=
[
  ['declineapplication_0',['declineApplication',['../classio_1_1agora_1_1chat_1_1_group_manager.html#aa08479a22f3154fce73eb1dfc062ae6b',1,'io::agora::chat::GroupManager']]],
  ['declineinvitation_1',['declineInvitation',['../classio_1_1agora_1_1chat_1_1_contact_manager.html#aa0b1151b2a828479acd9cd5400bcba47',1,'io.agora.chat.ContactManager.declineInvitation()'],['../classio_1_1agora_1_1chat_1_1_group_manager.html#ac276a6e808ccf34dd6f543f5076390ab',1,'io.agora.chat.GroupManager.declineInvitation()']]],
  ['deletecontact_2',['deleteContact',['../classio_1_1agora_1_1chat_1_1_contact_manager.html#aa242781a3dafd4e9f3e5a3287b661da9',1,'io.agora.chat.ContactManager.deleteContact(String username)'],['../classio_1_1agora_1_1chat_1_1_contact_manager.html#a20e94ff3ffe37b19867645c37d4bf2b7',1,'io.agora.chat.ContactManager.deleteContact(String username, boolean keepConversation)']]],
  ['deleteconversation_3',['deleteConversation',['../classio_1_1agora_1_1chat_1_1_chat_manager.html#a55f9d270ea1638fc556c3325ac348488',1,'io::agora::chat::ChatManager']]],
  ['deleteconversationfromserver_4',['deleteConversationFromServer',['../classio_1_1agora_1_1chat_1_1_chat_manager.html#a87b72cbb30e1636d290cc51062a27b53',1,'io::agora::chat::ChatManager']]],
  ['deletegroupsharedfile_5',['deleteGroupSharedFile',['../classio_1_1agora_1_1chat_1_1_group_manager.html#af0ff27c008a5e10827f900d2930833b9',1,'io::agora::chat::GroupManager']]],
  ['deletemessagesbeforetimestamp_6',['deleteMessagesBeforeTimestamp',['../classio_1_1agora_1_1chat_1_1_chat_manager.html#a23b0355ffd351da0b203f6e0c130fdf6',1,'io::agora::chat::ChatManager']]],
  ['deletemessagesonleavechatroom_7',['deleteMessagesOnLeaveChatroom',['../classio_1_1agora_1_1chat_1_1_chat_options.html#a7d5575c86eb8276da57d797239170646',1,'io::agora::chat::ChatOptions']]],
  ['deletemessagesonleavegroup_8',['deleteMessagesOnLeaveGroup',['../classio_1_1agora_1_1chat_1_1_chat_options.html#a5ddc56d1bdee3fb87f6cbe020b7952e3',1,'io::agora::chat::ChatOptions']]],
  ['deliveronlineonly_9',['deliverOnlineOnly',['../classio_1_1agora_1_1chat_1_1_chat_message.html#ad34bc5e96383f733c37eb9cc25c1a501',1,'io.agora.chat.ChatMessage.deliverOnlineOnly()'],['../classio_1_1agora_1_1chat_1_1_cmd_message_body.html#abb15a47e2b611887572db0c8bce40cc9',1,'io.agora.chat.CmdMessageBody.deliverOnlineOnly()']]],
  ['destroychatroom_10',['destroyChatRoom',['../classio_1_1agora_1_1chat_1_1_chat_room_manager.html#a0d50d2e34d9992fc3f8ea1c82e2db1a7',1,'io::agora::chat::ChatRoomManager']]],
  ['destroychatthread_11',['destroyChatThread',['../classio_1_1agora_1_1chat_1_1_chat_thread_manager.html#a1db8b9a11be721b9cab497de627b11d1',1,'io::agora::chat::ChatThreadManager']]],
  ['destroygroup_12',['destroyGroup',['../classio_1_1agora_1_1chat_1_1_group_manager.html#a5e7d0003169ef585142f8081c2c0c326',1,'io::agora::chat::GroupManager']]],
  ['direct_13',['direct',['../classio_1_1agora_1_1chat_1_1_chat_message.html#a6159ec1e08d6152e552fb2a37f6278be',1,'io::agora::chat::ChatMessage']]],
  ['disableofflinepush_14',['disableOfflinePush',['../classio_1_1agora_1_1chat_1_1_push_manager.html#a7392889db464509b768ceb8837c4a329',1,'io::agora::chat::PushManager']]],
  ['displayname_15',['displayName',['../classio_1_1agora_1_1chat_1_1_file_message_body.html#a4b42cf1852daaea1e5e408d7d297159a',1,'io::agora::chat::FileMessageBody']]],
  ['downloadandparsecombinemessage_16',['downloadAndParseCombineMessage',['../classio_1_1agora_1_1chat_1_1_chat_manager.html#a16d759e8cc6d5b642d30f8787f522b43',1,'io::agora::chat::ChatManager']]],
  ['downloadattachment_17',['downloadAttachment',['../classio_1_1agora_1_1chat_1_1_chat_manager.html#af5298f55319dd769b69623c111cc8dcb',1,'io::agora::chat::ChatManager']]],
  ['downloadgroupsharedfile_18',['downloadGroupSharedFile',['../classio_1_1agora_1_1chat_1_1_group_manager.html#adb634eee6c44805cc6fe25d017f65f7e',1,'io::agora::chat::GroupManager']]],
  ['downloadstatus_19',['downloadStatus',['../classio_1_1agora_1_1chat_1_1_file_message_body.html#a33fd2ec80c1fe01db7c810a66c4bb22d',1,'io::agora::chat::FileMessageBody']]],
  ['downloadthumbnail_20',['downloadThumbnail',['../classio_1_1agora_1_1chat_1_1_chat_manager.html#abdc79b8af968ba4f4a00d326746b0013',1,'io::agora::chat::ChatManager']]]
];
