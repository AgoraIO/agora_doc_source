var searchData=
[
  ['joinchatroom_0',['joinChatRoom',['../classio_1_1agora_1_1chat_1_1_chat_room_manager.html#a895dbd6d0217ba08bcf2dbb6cf441591',1,'io::agora::chat::ChatRoomManager']]],
  ['joinchatthread_1',['joinChatThread',['../classio_1_1agora_1_1chat_1_1_chat_thread_manager.html#a94574bb0d5738f6fc40d45fb15b8e4b3',1,'io::agora::chat::ChatThreadManager']]],
  ['joingroup_2',['joinGroup',['../classio_1_1agora_1_1chat_1_1_group_manager.html#a4471175b2adeb430b63adb54d35b3068',1,'io::agora::chat::GroupManager']]]
];
