var searchData=
[
  ['network_5ferror_0',['NETWORK_ERROR',['../classio_1_1agora_1_1_error.html#a1565a003d5e4653cab9bfdc16c7dfd85',1,'io::agora::Error']]],
  ['none_1',['none',['../enumio_1_1agora_1_1chat_1_1_chat_room_1_1_chat_room_permission_type.html#af587b9d9eece0628b8c56b797b0e0966',1,'io.agora.chat.ChatRoom.ChatRoomPermissionType.none()'],['../enumio_1_1agora_1_1chat_1_1_group_1_1_group_permission_type.html#a7338ad99e2ee3b68a8728085313c3ac3',1,'io.agora.chat.Group.GroupPermissionType.none()']]],
  ['none_2',['NONE',['../enumio_1_1agora_1_1chat_1_1_push_manager_1_1_push_remind_type.html#a83e0c77398f4f3892eb778a2680934ce',1,'io::agora::chat::PushManager::PushRemindType']]],
  ['normal_3',['NORMAL',['../enumio_1_1agora_1_1push_1_1_push_type.html#ab1c1b9d88568127b11f6837e36a5f396',1,'io::agora::push::PushType']]]
];
