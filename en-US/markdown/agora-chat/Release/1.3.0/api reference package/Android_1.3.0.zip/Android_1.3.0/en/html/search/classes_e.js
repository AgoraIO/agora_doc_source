var searchData=
[
  ['userinfo_0',['UserInfo',['../classio_1_1agora_1_1chat_1_1_user_info.html',1,'io::agora::chat']]],
  ['userinfomanager_1',['UserInfoManager',['../classio_1_1agora_1_1chat_1_1_user_info_manager.html',1,'io::agora::chat']]]
];
