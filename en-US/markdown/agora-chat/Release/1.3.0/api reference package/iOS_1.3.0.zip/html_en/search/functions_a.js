var searchData=
[
  ['kickalldeviceswithuserid_3atoken_3acompletion_3a_0',['kickAllDevicesWithUserId:token:completion:',['../interface_agora_chat_client.html#ace9345e1ed57bcc6349cf68503631586',1,'AgoraChatClient']]],
  ['kickalldeviceswithusername_3apassword_3a_1',['kickAllDevicesWithUsername:password:',['../interface_agora_chat_client.html#a54192ba8ea9f07d2261d847f3483dc9a',1,'AgoraChatClient']]],
  ['kickalldeviceswithusername_3apassword_3acompletion_3a_2',['kickAllDevicesWithUsername:password:completion:',['../interface_agora_chat_client.html#a1fb86b3614326d65a74108eaa1071973',1,'AgoraChatClient']]],
  ['kickdevicewithuserid_3atoken_3aresource_3acompletion_3a_3',['kickDeviceWithUserId:token:resource:completion:',['../interface_agora_chat_client.html#aec62d375a2def5af9d1c12a5dc33bf4b',1,'AgoraChatClient']]],
  ['kickdevicewithusername_3apassword_3aresource_3a_4',['kickDeviceWithUsername:password:resource:',['../interface_agora_chat_client.html#a7f3ba59be8360a0538c6d38391881084',1,'AgoraChatClient']]],
  ['kickdevicewithusername_3apassword_3aresource_3acompletion_3a_5',['kickDeviceWithUsername:password:resource:completion:',['../interface_agora_chat_client.html#a05de0343153a9851a15cd2e55b7a9fe9',1,'AgoraChatClient']]]
];
