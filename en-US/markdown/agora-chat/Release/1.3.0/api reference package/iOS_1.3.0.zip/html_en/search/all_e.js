var searchData=
[
  ['nickname_0',['nickname',['../interface_agora_chat_user_info.html#a272ccbb2512df96f662fda05e4631b63',1,'AgoraChatUserInfo']]],
  ['nsobject_28coding_29_1',['NSObject(Coding)',['../category_n_s_object_07_coding_08.html',1,'']]]
];
