var searchData=
[
  ['iagorachatcontactmanager_2dp_0',['IAgoraChatContactManager-p',['../protocol_i_agora_chat_contact_manager-p.html',1,'']]],
  ['iagorachatgroupmanager_2dp_1',['IAgoraChatGroupManager-p',['../protocol_i_agora_chat_group_manager-p.html',1,'']]],
  ['iagorachatmanager_2dp_2',['IAgoraChatManager-p',['../protocol_i_agora_chat_manager-p.html',1,'']]],
  ['iagorachatpresencemanager_2dp_3',['IAgoraChatPresenceManager-p',['../protocol_i_agora_chat_presence_manager-p.html',1,'']]],
  ['iagorachatpushmanager_2dp_4',['IAgoraChatPushManager-p',['../protocol_i_agora_chat_push_manager-p.html',1,'']]],
  ['iagorachatroommanager_2dp_5',['IAgoraChatroomManager-p',['../protocol_i_agora_chatroom_manager-p.html',1,'']]],
  ['iagorachatstatisticsmanager_2dp_6',['IAgoraChatStatisticsManager-p',['../protocol_i_agora_chat_statistics_manager-p.html',1,'']]],
  ['iagorachatthreadmanager_2dp_7',['IAgoraChatThreadManager-p',['../protocol_i_agora_chat_thread_manager-p.html',1,'']]],
  ['iagorachattranslatemanager_2dp_8',['IAgoraChatTranslateManager-p',['../protocol_i_agora_chat_translate_manager-p.html',1,'']]],
  ['iagorachatuserinfomanager_2dp_9',['IAgoraChatUserInfoManager-p',['../protocol_i_agora_chat_user_info_manager-p.html',1,'']]]
];
