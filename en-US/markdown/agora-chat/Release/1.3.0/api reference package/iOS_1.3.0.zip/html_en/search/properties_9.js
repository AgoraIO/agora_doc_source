var searchData=
[
  ['languagecode_0',['languageCode',['../interface_agora_chat_translate_language.html#ac6e15b42865483f7eac47a1f71d56b63',1,'AgoraChatTranslateLanguage']]],
  ['languagename_1',['languageName',['../interface_agora_chat_translate_language.html#ab15f830ee95366904f3215d5a331249c',1,'AgoraChatTranslateLanguage']]],
  ['languagenativename_2',['languageNativeName',['../interface_agora_chat_translate_language.html#abe0c8f14ff04e7022b58d45eb5dbf288',1,'AgoraChatTranslateLanguage']]],
  ['lastmessage_3',['lastMessage',['../interface_agora_chat_thread.html#a022b528576dbe62f577f47c17ff40973',1,'AgoraChatThread']]],
  ['lasttime_4',['lastTime',['../interface_agora_chat_presence.html#a45775010ce5d80639c97df912d69fc3b',1,'AgoraChatPresence']]],
  ['latestmessage_5',['latestMessage',['../interface_agora_chat_conversation.html#a3699cdee72536d67467d8d8407b991e5',1,'AgoraChatConversation']]],
  ['latitude_6',['latitude',['../interface_agora_chat_location_message_body.html#a922ca74506594c28136671d503e5298c',1,'AgoraChatLocationMessageBody']]],
  ['loademptyconversations_7',['loadEmptyConversations',['../interface_agora_chat_options.html#ada70febedd5350be01e30c342ec6f9b2',1,'AgoraChatOptions']]],
  ['localpath_8',['localPath',['../interface_agora_chat_file_message_body.html#a8bd45529c1159336f78506c1e231ae75',1,'AgoraChatFileMessageBody']]],
  ['localtime_9',['localTime',['../interface_agora_chat_message.html#abb99a444b59a1c15a5a2446b7cb75775',1,'AgoraChatMessage']]],
  ['loglevel_10',['logLevel',['../interface_agora_chat_options.html#ab61736e125e3ad8fd117acc2db88d970',1,'AgoraChatOptions']]],
  ['longitude_11',['longitude',['../interface_agora_chat_location_message_body.html#a190c3f5fe4b564dc6b35f8d9e4debbec',1,'AgoraChatLocationMessageBody']]]
];
