var searchData=
[
  ['onattributeschangedofgroupmember_3auserid_3aattributes_3aoperatorid_3a_0',['onAttributesChangedOfGroupMember:userId:attributes:operatorId:',['../protocol_agora_chat_group_manager_delegate-p.html#a82e5e43c0e8ddb399fc6fd6a0ec2b96b',1,'AgoraChatGroupManagerDelegate-p']]],
  ['onchatthreadcreate_3a_1',['onChatThreadCreate:',['../protocol_agora_chat_thread_manager_delegate-p.html#aaf7005f53dc3245da352c0aa83c4f342',1,'AgoraChatThreadManagerDelegate-p']]],
  ['onchatthreaddestroy_3a_2',['onChatThreadDestroy:',['../protocol_agora_chat_thread_manager_delegate-p.html#a69f85257fb21e57df1ddf16f2671386e',1,'AgoraChatThreadManagerDelegate-p']]],
  ['onchatthreadupdate_3a_3',['onChatThreadUpdate:',['../protocol_agora_chat_thread_manager_delegate-p.html#a2bd745657949c7a2b3f42cca8acda81a',1,'AgoraChatThreadManagerDelegate-p']]],
  ['onconversationread_3ato_3a_4',['onConversationRead:to:',['../protocol_agora_chat_manager_delegate-p.html#ace62082b9c63770b86100cea4d4b8beb',1,'AgoraChatManagerDelegate-p']]],
  ['onmessagecontentchanged_3aoperatorid_3aoperationtime_3a_5',['onMessageContentChanged:operatorId:operationTime:',['../protocol_agora_chat_manager_delegate-p.html#ab4bcca23824db72ca809d2d31ba27a66',1,'AgoraChatManagerDelegate-p']]],
  ['onmessagepinchanged_3aconversationid_3aoperation_3apininfo_3a_6',['onMessagePinChanged:conversationId:operation:pinInfo:',['../protocol_agora_chat_manager_delegate-p.html#ab24da7d2cb5022d87c150c7aea73613f',1,'AgoraChatManagerDelegate-p']]],
  ['onuserkickoutofchatthread_3a_7',['onUserKickOutOfChatThread:',['../protocol_agora_chat_thread_manager_delegate-p.html#ab15f010f6951b1b9f5892cc21dc7a4dd',1,'AgoraChatThreadManagerDelegate-p']]],
  ['optionswithappkey_3a_8',['optionsWithAppkey:',['../interface_agora_chat_options.html#a9d15b2b55a361a5ecfd1884833adfb8a',1,'AgoraChatOptions']]]
];
