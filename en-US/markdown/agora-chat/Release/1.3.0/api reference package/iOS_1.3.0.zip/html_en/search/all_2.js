var searchData=
[
  ['binddevicetoken_3a_0',['bindDeviceToken:',['../interface_agora_chat_client.html#a636722c4ce64f3cc8175237cf985ba68',1,'AgoraChatClient']]],
  ['bindfcmtoken_3acompletion_3a_1',['bindFCMToken:completion:',['../interface_agora_chat_client.html#a21180b0eb22d69ee01b2454deac57860',1,'AgoraChatClient']]],
  ['bindpushkittoken_3a_2',['bindPushKitToken:',['../interface_agora_chat_client.html#aa6a7e487d32730d90e8221913e9c5635',1,'AgoraChatClient']]],
  ['birth_3',['birth',['../interface_agora_chat_user_info.html#a3a6ba1221a403debb71521327f9e0fa0',1,'AgoraChatUserInfo']]],
  ['blacklist_4',['blacklist',['../interface_agora_chat_group.html#a6c1a063289782519c7ee4e62cf45fe92',1,'AgoraChatGroup::blacklist()'],['../interface_agora_chatroom.html#a431f3f75f2c42e9a82bb31706e474774',1,'AgoraChatroom::blacklist()']]],
  ['blockgroup_3acompletion_3a_5',['blockGroup:completion:',['../protocol_i_agora_chat_group_manager-p.html#a4ae8888a6861700b863edec023c909df',1,'IAgoraChatGroupManager-p']]],
  ['blockgroup_3aerror_3a_6',['blockGroup:error:',['../protocol_i_agora_chat_group_manager-p.html#a724cd3216f497f1a938bb3b9b3f1254d',1,'IAgoraChatGroupManager-p']]],
  ['blockmembers_3afromchatroom_3acompletion_3a_7',['blockMembers:fromChatroom:completion:',['../protocol_i_agora_chatroom_manager-p.html#ab0416b78d681b916d641a73bf2bbd5f9',1,'IAgoraChatroomManager-p']]],
  ['blockmembers_3afromchatroom_3aerror_3a_8',['blockMembers:fromChatroom:error:',['../protocol_i_agora_chatroom_manager-p.html#a8f58298bff4b9b864fc1f01caa2e0661',1,'IAgoraChatroomManager-p']]],
  ['blockmembers_3afromgroup_3acompletion_3a_9',['blockMembers:fromGroup:completion:',['../protocol_i_agora_chat_group_manager-p.html#a16596a4747e45869fde77d7af93ff811',1,'IAgoraChatGroupManager-p']]],
  ['blockoccupants_3afromgroup_3aerror_3a_10',['blockOccupants:fromGroup:error:',['../protocol_i_agora_chat_group_manager-p.html#a0d0ae8f49f130ab0c1026259e30124f8',1,'IAgoraChatGroupManager-p']]],
  ['body_11',['body',['../interface_agora_chat_message.html#a6a096accd1821704571833eaaf124016',1,'AgoraChatMessage']]],
  ['broadcast_12',['broadcast',['../interface_agora_chat_message.html#a2784170c78bddf872914f1b6d70536b6',1,'AgoraChatMessage']]],
  ['buildingname_13',['buildingName',['../interface_agora_chat_location_message_body.html#a9048b2c3fc3a8ce3ad92eb28b9572210',1,'AgoraChatLocationMessageBody']]]
];
