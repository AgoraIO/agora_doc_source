var searchData=
[
  ['pageresultwithlist_3aandcount_3a_0',['pageResultWithList:andCount:',['../interface_agora_chat_page_result.html#abba42fcef86cb9a6856905087ec5ee37',1,'AgoraChatPageResult']]],
  ['pinconversation_3aispinned_3acompletionblock_3a_1',['pinConversation:isPinned:completionBlock:',['../protocol_i_agora_chat_manager-p.html#a08f44547f277b378d0bb80114846dad1',1,'IAgoraChatManager-p']]],
  ['pinmessage_3acompletion_3a_2',['pinMessage:completion:',['../protocol_i_agora_chat_manager-p.html#a8488644cf021ce10e59d619269e337db',1,'IAgoraChatManager-p']]],
  ['pinnedmessages_3',['pinnedMessages',['../interface_agora_chat_conversation.html#accaf4fd03ce0064fd7334a562837731c',1,'AgoraChatConversation']]],
  ['presencestatusdidchanged_3a_4',['presenceStatusDidChanged:',['../protocol_agora_chat_presence_manager_delegate-p.html#ad017483b3661aa66cac5cbcf2987c94c',1,'AgoraChatPresenceManagerDelegate-p']]],
  ['publishpresencewithdescription_3acompletion_3a_5',['publishPresenceWithDescription:completion:',['../protocol_i_agora_chat_presence_manager-p.html#acbea9c6c7f383d59625989d555e10c1b',1,'IAgoraChatPresenceManager-p']]]
];
