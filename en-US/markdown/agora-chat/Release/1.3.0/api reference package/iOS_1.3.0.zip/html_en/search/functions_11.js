var searchData=
[
  ['tokendidexpire_3a_0',['tokenDidExpire:',['../protocol_agora_chat_client_delegate-p.html#a8d3cf915bc0306e92b45b3665756b2de',1,'AgoraChatClientDelegate-p']]],
  ['tokenwillexpire_3a_1',['tokenWillExpire:',['../protocol_agora_chat_client_delegate-p.html#af68c557e5577cec205ca9599189c2699',1,'AgoraChatClientDelegate-p']]],
  ['translatemessage_3atargetlanguages_3acompletion_3a_2',['translateMessage:targetLanguages:completion:',['../protocol_i_agora_chat_manager-p.html#a043fd81f58ae229877bea95ff9bb1227',1,'IAgoraChatManager-p']]]
];
