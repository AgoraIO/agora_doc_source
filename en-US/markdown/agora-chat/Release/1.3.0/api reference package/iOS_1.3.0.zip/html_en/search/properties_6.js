var searchData=
[
  ['gender_0',['gender',['../interface_agora_chat_user_info.html#a77f1b3b4c945758ad59a400223ece24d',1,'AgoraChatUserInfo']]],
  ['groupackcount_1',['groupAckCount',['../interface_agora_chat_message.html#a6d53a8a2c4671822ec898776b35d46d5',1,'AgoraChatMessage']]],
  ['groupid_2',['groupId',['../interface_agora_chat_group.html#a3b523983609fe9eee499e32ae624e834',1,'AgoraChatGroup']]],
  ['groupmanager_3',['groupManager',['../interface_agora_chat_client.html#af31af4616cad2dd542e49fa855acb8cb',1,'AgoraChatClient']]],
  ['groupname_4',['groupName',['../interface_agora_chat_group.html#ac9f117abb2fbfd97fd66399a856b3a11',1,'AgoraChatGroup']]]
];
