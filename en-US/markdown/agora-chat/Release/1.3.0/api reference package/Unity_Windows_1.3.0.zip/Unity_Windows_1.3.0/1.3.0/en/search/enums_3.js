var searchData=
[
  ['grouppermissiontype_0',['GroupPermissionType',['../namespace_agora_chat.html#ad237b6d2eb1d74494a9edf19c66fed61',1,'AgoraChat']]],
  ['groupstyle_1',['GroupStyle',['../namespace_agora_chat.html#a78c8dcc8960a647beb75fb8dd1ebfa1c',1,'AgoraChat']]]
];
