var searchData=
[
  ['room_0',['Room',['../class_agora_chat_1_1_room.html',1,'AgoraChat']]],
  ['roommanager_1',['RoomManager',['../class_agora_chat_1_1_room_manager.html',1,'AgoraChat']]]
];
