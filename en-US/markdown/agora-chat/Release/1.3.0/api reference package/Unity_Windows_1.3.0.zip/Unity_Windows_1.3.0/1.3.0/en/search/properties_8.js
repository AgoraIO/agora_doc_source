var searchData=
[
  ['languagecode_0',['LanguageCode',['../class_agora_chat_1_1_support_language.html#ad29212bb7a9f49f009480e9394f27c75',1,'AgoraChat::SupportLanguage']]],
  ['languagename_1',['LanguageName',['../class_agora_chat_1_1_support_language.html#a1c02b1c0c6d68e6496199af8710af965',1,'AgoraChat::SupportLanguage']]],
  ['languagenativename_2',['LanguageNativeName',['../class_agora_chat_1_1_support_language.html#a479beed1a0e2153f9e4e7d086e6f4a09',1,'AgoraChat::SupportLanguage']]],
  ['lastmessage_3',['LastMessage',['../class_agora_chat_1_1_conversation.html#a2b1d733eecc63aef30f4466f43032837',1,'AgoraChat::Conversation']]],
  ['lastreceivedmessage_4',['LastReceivedMessage',['../class_agora_chat_1_1_conversation.html#a88695c39a182808da19dfd95b213f3a9',1,'AgoraChat::Conversation']]],
  ['latesttime_5',['LatestTime',['../class_agora_chat_1_1_presence.html#a9e55b715b537f4f430fde2ae32bf5106',1,'AgoraChat::Presence']]]
];
