var searchData=
[
  ['pagecount_0',['PageCount',['../class_agora_chat_1_1_page_result.html#a8012ea0d34a318a7aacdc77050025802',1,'AgoraChat::PageResult']]],
  ['permissiontype_1',['PermissionType',['../class_agora_chat_1_1_group.html#a023e80cf735add4b3b3002360ff598cf',1,'AgoraChat.Group.PermissionType()'],['../class_agora_chat_1_1_room.html#a5bf8c1841eb6dc1f1be4211bbf4bd18e',1,'AgoraChat.Room.PermissionType()']]],
  ['pinnedinfo_2',['PinnedInfo',['../class_agora_chat_1_1_message.html#af505ac210c7b34fa7433f56eb3e0a8a9',1,'AgoraChat::Message']]],
  ['presencemanager_3',['PresenceManager',['../class_agora_chat_1_1_s_d_k_client.html#a209e0006253727d1012e3a9a567e6e73',1,'AgoraChat::SDKClient']]],
  ['publisher_4',['Publisher',['../class_agora_chat_1_1_presence.html#ad42750da73b0cc573cd4082cb6d42c1e',1,'AgoraChat::Presence']]]
];
