var searchData=
[
  ['roommessagepriority_0',['RoomMessagePriority',['../namespace_agora_chat.html#aa6d032a78afa107bfed3ea28009b5ff7',1,'AgoraChat']]],
  ['roompermissiontype_1',['RoomPermissionType',['../namespace_agora_chat.html#a2b6f39a7c115fd66eb10ef26f8c9cb76',1,'AgoraChat']]]
];
