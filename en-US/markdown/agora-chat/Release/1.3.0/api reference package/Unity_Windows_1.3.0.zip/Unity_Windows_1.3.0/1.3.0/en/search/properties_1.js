var searchData=
[
  ['blocklist_0',['BlockList',['../class_agora_chat_1_1_group.html#ad62725a163606c68a45a6dcb80f620c9',1,'AgoraChat.Group.BlockList()'],['../class_agora_chat_1_1_room.html#a8e76d5bba1f783a60c49a1a46de7cb68',1,'AgoraChat.Room.BlockList()']]]
];
