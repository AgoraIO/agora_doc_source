var searchData=
[
  ['leavegroup_0',['LeaveGroup',['../class_agora_chat_1_1_group_manager.html#a43e775ab4c7cd3d3df50d969695c86b6',1,'AgoraChat::GroupManager']]],
  ['leaveroom_1',['LeaveRoom',['../class_agora_chat_1_1_room_manager.html#aac1cb6b779e6111d32aa3b18549c3767',1,'AgoraChat::RoomManager']]],
  ['leavethread_2',['LeaveThread',['../class_agora_chat_1_1_chat_thread_manager.html#ae1ec5c38e466499b45761129a9325d9e',1,'AgoraChat::ChatThreadManager']]],
  ['loadallconversations_3',['LoadAllConversations',['../class_agora_chat_1_1_chat_manager.html#ad642bb7b0ff01b41f1f1c2951109593b',1,'AgoraChat::ChatManager']]],
  ['loadmessage_4',['LoadMessage',['../class_agora_chat_1_1_chat_manager.html#aa5bb1a2cbeb7206aca8766ec18ba9261',1,'AgoraChat.ChatManager.LoadMessage()'],['../class_agora_chat_1_1_conversation.html#aef05c210556e77af8d62ea4e935d6567',1,'AgoraChat.Conversation.LoadMessage(string messageId)']]],
  ['loadmessages_5',['LoadMessages',['../class_agora_chat_1_1_conversation.html#a354260d7b1eaa460c4b0b79df2c78d32',1,'AgoraChat::Conversation']]],
  ['loadmessageswithkeyword_6',['LoadMessagesWithKeyword',['../class_agora_chat_1_1_conversation.html#a7de617098b4dbb8387e9db84b853b1d6',1,'AgoraChat::Conversation']]],
  ['loadmessageswithmsgtype_7',['LoadMessagesWithMsgType',['../class_agora_chat_1_1_conversation.html#ac4f9f2ae3b89b2be2a1733472ad81573',1,'AgoraChat::Conversation']]],
  ['loadmessageswithscope_8',['LoadMessagesWithScope',['../class_agora_chat_1_1_conversation.html#aec275d33ebb5541be4500c1f9990ec2c',1,'AgoraChat::Conversation']]],
  ['loadmessageswithtime_9',['LoadMessagesWithTime',['../class_agora_chat_1_1_conversation.html#af332546d9b72fba10b9c0bb678b1bf73',1,'AgoraChat::Conversation']]],
  ['locationbody_10',['LocationBody',['../class_agora_chat_1_1_message_body_1_1_location_body.html#a351b3f8e88026be6f9af2a0d6840dfb1',1,'AgoraChat::MessageBody::LocationBody']]],
  ['login_11',['Login',['../class_agora_chat_1_1_s_d_k_client.html#a1943fdf5f6b195946f8ba8113ffdbdf6',1,'AgoraChat::SDKClient']]],
  ['loginwithagoratoken_12',['LoginWithAgoraToken',['../class_agora_chat_1_1_s_d_k_client.html#a03d3ac54a4532956de1d2c7718eae099',1,'AgoraChat::SDKClient']]],
  ['loginwithtoken_13',['LoginWithToken',['../class_agora_chat_1_1_s_d_k_client.html#aa679efc13ae96f334a41d76e9c2674af',1,'AgoraChat::SDKClient']]],
  ['logout_14',['Logout',['../class_agora_chat_1_1_s_d_k_client.html#a98b67e590dbe9f6253449df9e82dd0c8',1,'AgoraChat::SDKClient']]]
];
