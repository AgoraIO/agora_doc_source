var searchData=
[
  ['unreadcount_0',['UnReadCount',['../class_agora_chat_1_1_conversation.html#abeee905ebb42d325f3fa73558fb4b1f8',1,'AgoraChat::Conversation']]],
  ['userid_1',['UserId',['../class_agora_chat_1_1_contact.html#a683c2cb2a83cc832142cd6ff54c3cce2',1,'AgoraChat::Contact']]],
  ['userinfomanager_2',['UserInfoManager',['../class_agora_chat_1_1_s_d_k_client.html#a9274bfd035fdf3acbc3229f54f96e318',1,'AgoraChat::SDKClient']]]
];
