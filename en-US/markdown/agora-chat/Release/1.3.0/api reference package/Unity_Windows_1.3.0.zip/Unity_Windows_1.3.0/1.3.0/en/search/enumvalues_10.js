var searchData=
[
  ['send_0',['SEND',['../namespace_agora_chat.html#ac17636c7a7b633f9c185876d850a44eea548e51fa67d541384e9585adf0db95dc',1,'AgoraChat']]],
  ['set_5fmetadata_1',['SET_METADATA',['../namespace_agora_chat.html#a219e2b8202944dcdef170dc529f8fe68a9bda5c8e0c075527c2c0d06abf19ec1b',1,'AgoraChat']]],
  ['string_2',['STRING',['../namespace_agora_chat.html#a292bc538f956ba5bf2976941df4b469ba63b588d5559f64f89a416e656880b949',1,'AgoraChat']]],
  ['success_3',['SUCCESS',['../namespace_agora_chat.html#a33be8ac1aa48dbbed69d5a7f40ffb131ad0749aaba8b833466dfcbb0428e4f89c',1,'AgoraChat.SUCCESS()'],['../namespace_agora_chat_1_1_message_body.html#a1c68f57689f3139b999693c8fec4546aad0749aaba8b833466dfcbb0428e4f89c',1,'AgoraChat.MessageBody.SUCCESS()']]]
];
