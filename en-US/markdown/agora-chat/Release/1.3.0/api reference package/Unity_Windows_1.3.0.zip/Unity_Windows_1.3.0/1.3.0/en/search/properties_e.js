var searchData=
[
  ['sdkversion_0',['SdkVersion',['../class_agora_chat_1_1_s_d_k_client.html#a1e1b0f65f4b85046af03eaf8cdbe4019',1,'AgoraChat::SDKClient']]],
  ['statusdescription_1',['StatusDescription',['../class_agora_chat_1_1_presence.html#a03483733389f0ea8c1499644c78e037b',1,'AgoraChat::Presence']]],
  ['statuslist_2',['StatusList',['../class_agora_chat_1_1_presence.html#a4ef6abcdc1e668e546e8d49587121b37',1,'AgoraChat::Presence']]]
];
