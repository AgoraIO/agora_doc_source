var searchData=
[
  ['video_0',['VIDEO',['../namespace_agora_chat.html#a8d167e073ca67f4f12657a2dde388df1ae60ae31f67ab883c746bb71c7a145c18',1,'AgoraChat']]],
  ['voice_1',['VOICE',['../namespace_agora_chat.html#a8d167e073ca67f4f12657a2dde388df1a9369ef98bb3f619078bb34cbf76ac6e4',1,'AgoraChat']]]
];
