var searchData=
[
  ['unblockgroup_0',['UnBlockGroup',['../class_agora_chat_1_1_group_manager.html#a60c33e5ccd132161bf5863d26423c1ca',1,'AgoraChat::GroupManager']]],
  ['unblockgroupmembers_1',['UnBlockGroupMembers',['../class_agora_chat_1_1_group_manager.html#ade48d48c2d4ee7622644e2e3bdb93a19',1,'AgoraChat::GroupManager']]],
  ['unblockroommembers_2',['UnBlockRoomMembers',['../class_agora_chat_1_1_room_manager.html#a0a3823a9deb23c2715c803c0c77fc33a',1,'AgoraChat::RoomManager']]],
  ['unmuteallroommembers_3',['UnMuteAllRoomMembers',['../class_agora_chat_1_1_room_manager.html#a75a807ae86cd75e8d00ded693242e5d3',1,'AgoraChat::RoomManager']]],
  ['unmutegroupallmembers_4',['UnMuteGroupAllMembers',['../class_agora_chat_1_1_group_manager.html#ac9a8a5fd1f9046a3f676d3554b246185',1,'AgoraChat::GroupManager']]],
  ['unmutegroupmembers_5',['UnMuteGroupMembers',['../class_agora_chat_1_1_group_manager.html#aaccd22495a8e16525befb7a64c5fc39e',1,'AgoraChat::GroupManager']]],
  ['unmuteroommembers_6',['UnMuteRoomMembers',['../class_agora_chat_1_1_room_manager.html#a89ff0174068bd19926b696914ee3b24b',1,'AgoraChat::RoomManager']]],
  ['unsubscribepresences_7',['UnsubscribePresences',['../class_agora_chat_1_1_presence_manager.html#a7df4ca3aa8f90e2d777be74b10cbb70a',1,'AgoraChat::PresenceManager']]],
  ['updategroupannouncement_8',['UpdateGroupAnnouncement',['../class_agora_chat_1_1_group_manager.html#a73967c3fd60ad7e01b6b324cdcb4673f',1,'AgoraChat::GroupManager']]],
  ['updategroupext_9',['UpdateGroupExt',['../class_agora_chat_1_1_group_manager.html#ab71d899cc60f036fe469a30f2135c5bf',1,'AgoraChat::GroupManager']]],
  ['updatemessage_10',['UpdateMessage',['../class_agora_chat_1_1_chat_manager.html#ab9a23c7c2628fba7c967901bc5e11248',1,'AgoraChat.ChatManager.UpdateMessage()'],['../class_agora_chat_1_1_conversation.html#a177877bf974c03286569139b87551dc9',1,'AgoraChat.Conversation.UpdateMessage()']]],
  ['updateowninfo_11',['UpdateOwnInfo',['../class_agora_chat_1_1_user_info_manager.html#a2ab4ddd0e3bc2d1f378cefc2011ce47d',1,'AgoraChat::UserInfoManager']]],
  ['updateroomannouncement_12',['UpdateRoomAnnouncement',['../class_agora_chat_1_1_room_manager.html#abff0294c07aa17a1ab4e0c3121d419ea',1,'AgoraChat::RoomManager']]],
  ['uploadgroupsharedfile_13',['UploadGroupSharedFile',['../class_agora_chat_1_1_group_manager.html#a6382731532f788298ba2a24f5394c280',1,'AgoraChat::GroupManager']]]
];
