var searchData=
[
  ['targetlanguages_0',['TargetLanguages',['../class_agora_chat_1_1_message_body_1_1_text_body.html#ada909c18640ce9ce17f0591a815371d3',1,'AgoraChat::MessageBody::TextBody']]],
  ['text_1',['Text',['../class_agora_chat_1_1_message_body_1_1_text_body.html#a4b7adb6388194c412849709f37bc9c22',1,'AgoraChat::MessageBody::TextBody']]],
  ['thumbnaildownstatus_2',['ThumbnailDownStatus',['../class_agora_chat_1_1_message_body_1_1_image_body.html#a43340ec6834ac16b1513cb4c72e4eba3',1,'AgoraChat.MessageBody.ImageBody.ThumbnailDownStatus()'],['../class_agora_chat_1_1_message_body_1_1_video_body.html#abef8c22b316ecb6ea53324fd9adc691a',1,'AgoraChat.MessageBody.VideoBody.ThumbnailDownStatus()']]],
  ['thumbnaillocalpath_3',['ThumbnailLocalPath',['../class_agora_chat_1_1_message_body_1_1_image_body.html#ab79575c0c86eeb903c44861710d76999',1,'AgoraChat::MessageBody::ImageBody']]],
  ['thumbnailocationpath_4',['ThumbnaiLocationPath',['../class_agora_chat_1_1_message_body_1_1_video_body.html#aea519d8ff9c34111a39de462758bd5a6',1,'AgoraChat::MessageBody::VideoBody']]],
  ['thumbnailremotepath_5',['ThumbnailRemotePath',['../class_agora_chat_1_1_message_body_1_1_image_body.html#a037abad81122992410e1dede63d0147e',1,'AgoraChat.MessageBody.ImageBody.ThumbnailRemotePath()'],['../class_agora_chat_1_1_message_body_1_1_video_body.html#ab0e86e3fbdbaf1bb52e2a0f1cec5f4bc',1,'AgoraChat.MessageBody.VideoBody.ThumbnailRemotePath()']]],
  ['thumbnailsecret_6',['ThumbnailSecret',['../class_agora_chat_1_1_message_body_1_1_image_body.html#ac97370d3558fec83d9f2566ae7b886f9',1,'AgoraChat.MessageBody.ImageBody.ThumbnailSecret()'],['../class_agora_chat_1_1_message_body_1_1_video_body.html#aa33bb1319aaaa2ef91d181a7e8b92912',1,'AgoraChat.MessageBody.VideoBody.ThumbnailSecret()']]],
  ['tid_7',['Tid',['../class_agora_chat_1_1_chat_thread.html#a7e903aeff51cba5f4e76bb32791c22fd',1,'AgoraChat::ChatThread']]],
  ['title_8',['Title',['../class_agora_chat_1_1_message_body_1_1_combine_body.html#afc3e14242a332499668b127ee9806e3b',1,'AgoraChat::MessageBody::CombineBody']]],
  ['to_9',['To',['../class_agora_chat_1_1_message.html#aa274c94e2a988c5012c8c4514cd96b0e',1,'AgoraChat::Message']]],
  ['translations_10',['Translations',['../class_agora_chat_1_1_message_body_1_1_text_body.html#afcc686d1656f6216a9bdd3aee5fe5752',1,'AgoraChat::MessageBody::TextBody']]],
  ['type_11',['Type',['../class_agora_chat_1_1_conversation.html#af3c36a606d101abb18c7c4948c74533d',1,'AgoraChat::Conversation']]]
];
