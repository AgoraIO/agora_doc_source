var searchData=
[
  ['pinconversation_0',['PinConversation',['../class_agora_chat_1_1_chat_manager.html#acb512be243573632777589a106dc9181',1,'AgoraChat::ChatManager']]],
  ['pinmessage_1',['PinMessage',['../class_agora_chat_1_1_chat_manager.html#a5c6a2796ca2cc30f6f00d6dc3b78d3fd',1,'AgoraChat::ChatManager']]],
  ['pinnedmessages_2',['PinnedMessages',['../class_agora_chat_1_1_conversation.html#a4e604c934b217e7c009e1d5511d01278',1,'AgoraChat::Conversation']]],
  ['publishpresence_3',['PublishPresence',['../class_agora_chat_1_1_presence_manager.html#a3726836cc8aa15a8ffd89f83cb9f67ef',1,'AgoraChat::PresenceManager']]]
];
