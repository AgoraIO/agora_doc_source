var searchData=
[
  ['textbody_0',['TextBody',['../class_agora_chat_1_1_message_body_1_1_text_body.html',1,'AgoraChat::MessageBody']]]
];
