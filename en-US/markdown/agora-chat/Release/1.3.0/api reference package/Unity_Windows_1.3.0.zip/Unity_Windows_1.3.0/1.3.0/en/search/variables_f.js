var searchData=
[
  ['sdkdatapath_0',['SDKDataPath',['../class_agora_chat_1_1_options.html#afbe585a5379d5c89e684032803d5e51a',1,'AgoraChat::Options']]],
  ['secret_1',['Secret',['../class_agora_chat_1_1_message_body_1_1_file_body.html#a227d7c1e55f8bdc6ba8513fd9d4491b0',1,'AgoraChat::MessageBody::FileBody']]],
  ['servertime_2',['ServerTime',['../class_agora_chat_1_1_message.html#a4e61a8da5296a995751e059496dd28ec',1,'AgoraChat::Message']]],
  ['servertransfer_3',['ServerTransfer',['../class_agora_chat_1_1_options.html#a8653949f868134a2900176e44091a5ed',1,'AgoraChat::Options']]],
  ['signature_4',['Signature',['../class_agora_chat_1_1_user_info.html#a05fffc01b61d9fb8b079bddb00509e93',1,'AgoraChat::UserInfo']]],
  ['sortmessagebyservertime_5',['SortMessageByServerTime',['../class_agora_chat_1_1_options.html#ac30dbfc44586f40488b4344a1353fef4',1,'AgoraChat::Options']]],
  ['starttime_6',['StartTime',['../class_agora_chat_1_1_fetch_server_messages_option.html#ae184996e31424fd5cd239b5d38147892',1,'AgoraChat::FetchServerMessagesOption']]],
  ['state_7',['State',['../class_agora_chat_1_1_message_reaction.html#a17399b8d95e3f3bdd49379b9ab7777f2',1,'AgoraChat::MessageReaction']]],
  ['status_8',['Status',['../class_agora_chat_1_1_message.html#aa918c0bee098ebbb615c7147136fe6d5',1,'AgoraChat.Message.Status()'],['../class_agora_chat_1_1_presence_device_status.html#a8bbf122b66d211c52da9fa321e25f7a3',1,'AgoraChat.PresenceDeviceStatus.Status()']]],
  ['style_9',['Style',['../class_agora_chat_1_1_group_options.html#afa072aacdd6504b91845bc8c45f98015',1,'AgoraChat::GroupOptions']]],
  ['success_10',['Success',['../class_agora_chat_1_1_call_back.html#ac2495c5db6d86c329ba15ddcea98b41d',1,'AgoraChat::CallBack']]],
  ['summary_11',['Summary',['../class_agora_chat_1_1_message_body_1_1_combine_body.html#a11edaf0e9e8774577a8ac80fd9d6b3ec',1,'AgoraChat::MessageBody::CombineBody']]]
];
