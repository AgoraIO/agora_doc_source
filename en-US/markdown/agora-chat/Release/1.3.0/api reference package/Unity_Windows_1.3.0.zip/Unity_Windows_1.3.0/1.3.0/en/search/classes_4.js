var searchData=
[
  ['group_0',['Group',['../class_agora_chat_1_1_group.html',1,'AgoraChat']]],
  ['groupinfo_1',['GroupInfo',['../class_agora_chat_1_1_group_info.html',1,'AgoraChat']]],
  ['groupmanager_2',['GroupManager',['../class_agora_chat_1_1_group_manager.html',1,'AgoraChat']]],
  ['groupoptions_3',['GroupOptions',['../class_agora_chat_1_1_group_options.html',1,'AgoraChat']]],
  ['groupreadack_4',['GroupReadAck',['../class_agora_chat_1_1_group_read_ack.html',1,'AgoraChat']]],
  ['groupsharedfile_5',['GroupSharedFile',['../class_agora_chat_1_1_group_shared_file.html',1,'AgoraChat']]]
];
