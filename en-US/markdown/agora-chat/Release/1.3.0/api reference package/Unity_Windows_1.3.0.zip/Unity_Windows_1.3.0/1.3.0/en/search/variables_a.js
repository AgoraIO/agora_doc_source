var searchData=
[
  ['maxcount_0',['MaxCount',['../class_agora_chat_1_1_group_options.html#a597b10b687383656c585b8d398621ddd',1,'AgoraChat::GroupOptions']]],
  ['memberscount_1',['MembersCount',['../class_agora_chat_1_1_chat_thread.html#a1569946f0f64f79910c036ae448bb00e',1,'AgoraChat::ChatThread']]],
  ['messagecount_2',['MessageCount',['../class_agora_chat_1_1_chat_thread.html#a02e30662b668fe34670a839218967e4e',1,'AgoraChat::ChatThread']]],
  ['messageid_3',['MessageId',['../class_agora_chat_1_1_chat_thread.html#a6fbdad5578a9f420baaf5ce3be81ff4f',1,'AgoraChat.ChatThread.MessageId()'],['../class_agora_chat_1_1_message_reaction_change.html#adfae8eab511d47203abf90119cc922f2',1,'AgoraChat.MessageReactionChange.MessageId()']]],
  ['messagelist_4',['MessageList',['../class_agora_chat_1_1_message_body_1_1_combine_body.html#a09333da6e7ae5d6a72f5581cc1b36cfd',1,'AgoraChat::MessageBody::CombineBody']]],
  ['messageonlinestate_5',['MessageOnlineState',['../class_agora_chat_1_1_message.html#a5970d530e3d5fd2010e1298874d594da',1,'AgoraChat::Message']]],
  ['messagetype_6',['MessageType',['../class_agora_chat_1_1_message.html#ac48d62a9c691390e9fd5c4d07903f93d',1,'AgoraChat::Message']]],
  ['msgid_7',['MsgId',['../class_agora_chat_1_1_message.html#ac058e1ef3fba34f0cd0ba542c50e25df',1,'AgoraChat::Message']]],
  ['msgtypes_8',['MsgTypes',['../class_agora_chat_1_1_fetch_server_messages_option.html#a408f23baa632b74de47d4b01feffbbc3',1,'AgoraChat::FetchServerMessagesOption']]],
  ['myuuid_9',['MyUUID',['../class_agora_chat_1_1_options.html#a2175db66e4195fab1a593eab4cb87bea',1,'AgoraChat::Options']]]
];
