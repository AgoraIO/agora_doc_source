var searchData=
[
  ['bool_0',['BOOL',['../namespace_agora_chat.html#a292bc538f956ba5bf2976941df4b469baa97b2c144243b2b9d2c593ec268b62f5',1,'AgoraChat']]]
];
