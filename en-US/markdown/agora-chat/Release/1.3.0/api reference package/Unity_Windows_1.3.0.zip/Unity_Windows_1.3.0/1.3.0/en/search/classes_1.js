var searchData=
[
  ['deviceinfo_0',['DeviceInfo',['../class_agora_chat_1_1_device_info.html',1,'AgoraChat']]]
];
