var searchData=
[
  ['locationbody_0',['LocationBody',['../class_agora_chat_1_1_message_body_1_1_location_body.html',1,'AgoraChat::MessageBody']]]
];
