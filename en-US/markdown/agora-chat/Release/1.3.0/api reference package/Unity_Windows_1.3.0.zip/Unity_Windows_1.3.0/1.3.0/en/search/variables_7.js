var searchData=
[
  ['hasdeliverack_0',['HasDeliverAck',['../class_agora_chat_1_1_message.html#a8eb699cefe220e7f7b66a80df81e3089',1,'AgoraChat::Message']]],
  ['hasreadack_1',['HasReadAck',['../class_agora_chat_1_1_message.html#a9c14308a396cdc27846a619de250b93f',1,'AgoraChat::Message']]],
  ['height_2',['Height',['../class_agora_chat_1_1_message_body_1_1_image_body.html#a2a446d79ce8bc8da17284f2c4124398b',1,'AgoraChat.MessageBody.ImageBody.Height()'],['../class_agora_chat_1_1_message_body_1_1_video_body.html#ac0516530c89ffecac259b2fa5fc050fe',1,'AgoraChat.MessageBody.VideoBody.Height()']]]
];
