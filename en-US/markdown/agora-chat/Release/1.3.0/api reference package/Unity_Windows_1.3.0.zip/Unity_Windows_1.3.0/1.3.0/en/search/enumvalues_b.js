var searchData=
[
  ['member_0',['Member',['../namespace_agora_chat.html#ad237b6d2eb1d74494a9edf19c66fed61a858ba4765e53c712ef672a9570474b1d',1,'AgoraChat.Member()'],['../namespace_agora_chat.html#a2b6f39a7c115fd66eb10ef26f8c9cb76a858ba4765e53c712ef672a9570474b1d',1,'AgoraChat.Member()']]],
  ['messagereactionoperateadd_1',['MessageReactionOperateAdd',['../namespace_agora_chat.html#a98b511c8159c31c0e77a9505f3c96f6dab10069b4701728befc0c11d09df7056f',1,'AgoraChat']]],
  ['messagereactionoperateremove_2',['MessageReactionOperateRemove',['../namespace_agora_chat.html#a98b511c8159c31c0e77a9505f3c96f6daa67ef401cbba1939a06c094cd1036239',1,'AgoraChat']]]
];
