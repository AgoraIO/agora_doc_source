var searchData=
[
  ['threadmanager_0',['ThreadManager',['../class_agora_chat_1_1_s_d_k_client.html#a71e5e5b3e7e421837a2fbd76f5a49bcc',1,'AgoraChat::SDKClient']]],
  ['timestamp_1',['Timestamp',['../class_agora_chat_1_1_group_read_ack.html#ab96a82170658a4a33ad9f389d9f6930f',1,'AgoraChat::GroupReadAck']]]
];
