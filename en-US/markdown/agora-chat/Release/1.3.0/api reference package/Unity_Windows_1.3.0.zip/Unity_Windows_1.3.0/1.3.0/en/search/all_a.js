var searchData=
[
  ['kickalldevices_0',['KickAllDevices',['../class_agora_chat_1_1_s_d_k_client.html#a9a90937f5ab0fb9ca889fa3abbd34755',1,'AgoraChat::SDKClient']]],
  ['kickalldeviceswithtoken_1',['KickAllDevicesWithToken',['../class_agora_chat_1_1_s_d_k_client.html#a61406faaac6c50924e68962aeb5ea6d0',1,'AgoraChat::SDKClient']]],
  ['kickdevice_2',['KickDevice',['../class_agora_chat_1_1_s_d_k_client.html#ac1a775bc3545fe8d14e181c1cae7848d',1,'AgoraChat::SDKClient']]],
  ['kickdevicewithtoken_3',['KickDeviceWithToken',['../class_agora_chat_1_1_s_d_k_client.html#a5dd2a720dc00feb730d68e9df4af512c',1,'AgoraChat::SDKClient']]]
];
