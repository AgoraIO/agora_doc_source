var searchData=
[
  ['markallconversationsasread_0',['MarkAllConversationsAsRead',['../class_agora_chat_1_1_chat_manager.html#a1eca8e4bca8cbb62d20ede759ce70edc',1,'AgoraChat::ChatManager']]],
  ['markallmessageasread_1',['MarkAllMessageAsRead',['../class_agora_chat_1_1_conversation.html#aa4fabdb0b7f6adce27d13f9df0736c45',1,'AgoraChat::Conversation']]],
  ['markconversations_2',['MarkConversations',['../class_agora_chat_1_1_chat_manager.html#abfdbaa93f1a9db988ae3fbc4557ef75d',1,'AgoraChat::ChatManager']]],
  ['markmessageasread_3',['MarkMessageAsRead',['../class_agora_chat_1_1_conversation.html#a96a792f76191983d6f25aae0d73d4c71',1,'AgoraChat::Conversation']]],
  ['marks_4',['Marks',['../class_agora_chat_1_1_conversation.html#a95d49a7c7a98f99adc63f5ba14da7dc3',1,'AgoraChat::Conversation']]],
  ['messagereactiondidchange_5',['MessageReactionDidChange',['../interface_agora_chat_1_1_i_chat_manager_delegate.html#ac85aca15e5ae239eb4a9fb861fda8f88',1,'AgoraChat::IChatManagerDelegate']]],
  ['messagescount_6',['MessagesCount',['../class_agora_chat_1_1_conversation.html#a19e30070920fabe88cc6f9395fd1c472',1,'AgoraChat::Conversation']]],
  ['modifymessage_7',['ModifyMessage',['../class_agora_chat_1_1_chat_manager.html#a406cc7536230123d294b6213b74c3a7e',1,'AgoraChat::ChatManager']]],
  ['muteallroommembers_8',['MuteAllRoomMembers',['../class_agora_chat_1_1_room_manager.html#a172bbd43aab0f7770c15b92a76424466',1,'AgoraChat::RoomManager']]],
  ['mutegroupallmembers_9',['MuteGroupAllMembers',['../class_agora_chat_1_1_group_manager.html#af9653dc4e5aae655e9a0ddac3e927aae',1,'AgoraChat::GroupManager']]],
  ['mutegroupmembers_10',['MuteGroupMembers',['../class_agora_chat_1_1_group_manager.html#abbec16cf7e1e296395571e1cf844eba3',1,'AgoraChat::GroupManager']]],
  ['muteroommembers_11',['MuteRoomMembers',['../class_agora_chat_1_1_room_manager.html#a09fddc581ba15d85633d802cd379479d',1,'AgoraChat::RoomManager']]]
];
