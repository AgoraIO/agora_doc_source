var searchData=
[
  ['joinpublicgroup_0',['JoinPublicGroup',['../class_agora_chat_1_1_group_manager.html#a999e21f75ee72f8337c1e19d4cd64c44',1,'AgoraChat::GroupManager']]],
  ['joinroom_1',['JoinRoom',['../class_agora_chat_1_1_room_manager.html#ae186f9f19ff2c1f5c4506263b6b1ffb0',1,'AgoraChat::RoomManager']]],
  ['jointhread_2',['JoinThread',['../class_agora_chat_1_1_chat_thread_manager.html#a3800e631352720c1b07a60b36993b8ca',1,'AgoraChat::ChatThreadManager']]]
];
