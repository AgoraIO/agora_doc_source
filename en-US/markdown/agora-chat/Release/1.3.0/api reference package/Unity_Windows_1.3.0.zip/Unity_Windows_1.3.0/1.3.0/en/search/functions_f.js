var searchData=
[
  ['textbody_0',['TextBody',['../class_agora_chat_1_1_message_body_1_1_text_body.html#a6ad17c810175dce1cfbba776d4e06be7',1,'AgoraChat::MessageBody::TextBody']]],
  ['translatemessage_1',['TranslateMessage',['../class_agora_chat_1_1_chat_manager.html#aec0aa99d2bdf2b9746b53d0a54eb1729',1,'AgoraChat::ChatManager']]]
];
