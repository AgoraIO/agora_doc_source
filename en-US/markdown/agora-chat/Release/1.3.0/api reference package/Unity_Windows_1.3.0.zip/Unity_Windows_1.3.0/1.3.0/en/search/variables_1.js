var searchData=
[
  ['birth_0',['Birth',['../class_agora_chat_1_1_user_info.html#a8e65d63852106c8af371181dbca8107a',1,'AgoraChat::UserInfo']]],
  ['body_1',['Body',['../class_agora_chat_1_1_message.html#a54f78096cd4391425071a5f78081bb39',1,'AgoraChat::Message']]],
  ['broadcast_2',['Broadcast',['../class_agora_chat_1_1_message.html#aee0e2646cdf48f62f9dea699546e7260',1,'AgoraChat::Message']]],
  ['buildingname_3',['BuildingName',['../class_agora_chat_1_1_message_body_1_1_location_body.html#a2932e03caacd84596fd871d6d2e785bc',1,'AgoraChat::MessageBody::LocationBody']]]
];
