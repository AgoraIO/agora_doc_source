var searchData=
[
  ['receiverlist_0',['ReceiverList',['../class_agora_chat_1_1_message.html#a6610a23e726c30483e5138e22380802b',1,'AgoraChat::Message']]],
  ['remark_1',['Remark',['../class_agora_chat_1_1_contact.html#a0d656addf0356666ac015c6c82bf293d',1,'AgoraChat::Contact']]],
  ['resource_2',['Resource',['../class_agora_chat_1_1_device_info.html#a0dc613a9a6933610b7ec1b3650d2897d',1,'AgoraChat::DeviceInfo']]],
  ['roomid_3',['RoomId',['../class_agora_chat_1_1_room.html#a4d6ec54428e0f4a0fdc0fa36e5e3cd6d',1,'AgoraChat::Room']]],
  ['roommanager_4',['RoomManager',['../class_agora_chat_1_1_s_d_k_client.html#a573e067d20c24951ee97b801102dc0e2',1,'AgoraChat::SDKClient']]]
];
