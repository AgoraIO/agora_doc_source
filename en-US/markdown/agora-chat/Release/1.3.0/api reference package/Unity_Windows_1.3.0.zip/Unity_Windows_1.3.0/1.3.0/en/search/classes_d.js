var searchData=
[
  ['userinfo_0',['UserInfo',['../class_agora_chat_1_1_user_info.html',1,'AgoraChat']]],
  ['userinfomanager_1',['UserInfoManager',['../class_agora_chat_1_1_user_info_manager.html',1,'AgoraChat']]]
];
