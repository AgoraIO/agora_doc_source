var searchData=
[
  ['name_0',['Name',['../class_agora_chat_1_1_group.html#a73c4c1d90695a9fd34e4a8d897b69f54',1,'AgoraChat.Group.Name()'],['../class_agora_chat_1_1_room.html#a3dcd7990b14caf48df39eeef0b6ee72b',1,'AgoraChat.Room.Name()']]],
  ['noticeenabled_1',['NoticeEnabled',['../class_agora_chat_1_1_group.html#aedc23cc6bdff12f0d3f7b6752bebdcf9',1,'AgoraChat::Group']]]
];
