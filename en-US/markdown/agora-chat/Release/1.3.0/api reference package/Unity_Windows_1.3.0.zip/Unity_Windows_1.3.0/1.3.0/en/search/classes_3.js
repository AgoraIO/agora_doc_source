var searchData=
[
  ['fetchservermessagesoption_0',['FetchServerMessagesOption',['../class_agora_chat_1_1_fetch_server_messages_option.html',1,'AgoraChat']]],
  ['filebody_1',['FileBody',['../class_agora_chat_1_1_message_body_1_1_file_body.html',1,'AgoraChat::MessageBody']]]
];
