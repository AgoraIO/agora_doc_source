var searchData=
[
  ['birth_0',['Birth',['../class_agora_chat_1_1_user_info.html#a8e65d63852106c8af371181dbca8107a',1,'AgoraChat::UserInfo']]],
  ['blockgroup_1',['BlockGroup',['../class_agora_chat_1_1_group_manager.html#a63fa55e7c57831fa54d5e8e716cfabb5',1,'AgoraChat::GroupManager']]],
  ['blockgroupmembers_2',['BlockGroupMembers',['../class_agora_chat_1_1_group_manager.html#a4a724345647afadb39f43aa1724e77db',1,'AgoraChat::GroupManager']]],
  ['blocklist_3',['BlockList',['../class_agora_chat_1_1_group.html#ad62725a163606c68a45a6dcb80f620c9',1,'AgoraChat.Group.BlockList()'],['../class_agora_chat_1_1_room.html#a8e76d5bba1f783a60c49a1a46de7cb68',1,'AgoraChat.Room.BlockList()']]],
  ['blockroommembers_4',['BlockRoomMembers',['../class_agora_chat_1_1_room_manager.html#a02097b33464e047003d5b6de0e3088d3',1,'AgoraChat::RoomManager']]],
  ['body_5',['Body',['../class_agora_chat_1_1_message.html#a54f78096cd4391425071a5f78081bb39',1,'AgoraChat::Message']]],
  ['bool_6',['BOOL',['../namespace_agora_chat.html#a292bc538f956ba5bf2976941df4b469baa97b2c144243b2b9d2c593ec268b62f5',1,'AgoraChat']]],
  ['broadcast_7',['Broadcast',['../class_agora_chat_1_1_message.html#aee0e2646cdf48f62f9dea699546e7260',1,'AgoraChat::Message']]],
  ['buildingname_8',['BuildingName',['../class_agora_chat_1_1_message_body_1_1_location_body.html#a2932e03caacd84596fd871d6d2e785bc',1,'AgoraChat::MessageBody::LocationBody']]]
];
