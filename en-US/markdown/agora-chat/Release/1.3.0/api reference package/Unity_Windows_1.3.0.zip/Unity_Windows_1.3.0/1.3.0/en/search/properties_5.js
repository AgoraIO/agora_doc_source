var searchData=
[
  ['fileid_0',['FileId',['../class_agora_chat_1_1_group_shared_file.html#ac17b05e8d84d729de0de680f0a1bf306',1,'AgoraChat::GroupSharedFile']]],
  ['filename_1',['FileName',['../class_agora_chat_1_1_group_shared_file.html#a0084f51b3218d91deb5457c94f1fdc96',1,'AgoraChat::GroupSharedFile']]],
  ['fileowner_2',['FileOwner',['../class_agora_chat_1_1_group_shared_file.html#a97f91f9218a33bbbad3709979854b647',1,'AgoraChat::GroupSharedFile']]],
  ['filesize_3',['FileSize',['../class_agora_chat_1_1_group_shared_file.html#ac0490e62055e8789f58e20aa94cc1c66',1,'AgoraChat::GroupSharedFile']]],
  ['from_4',['From',['../class_agora_chat_1_1_chat_thread_event.html#a54ec4322f1e2cb219a5c2610e6d955c4',1,'AgoraChat.ChatThreadEvent.From()'],['../class_agora_chat_1_1_group_read_ack.html#ae2fdbe115427b2f1125de362b3cb3919',1,'AgoraChat.GroupReadAck.From()']]]
];
