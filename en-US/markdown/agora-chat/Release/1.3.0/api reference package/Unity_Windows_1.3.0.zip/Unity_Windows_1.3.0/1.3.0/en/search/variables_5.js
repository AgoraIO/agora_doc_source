var searchData=
[
  ['filesize_0',['FileSize',['../class_agora_chat_1_1_message_body_1_1_file_body.html#a0278da9fe26e8dbb024f0871eef034ac',1,'AgoraChat::MessageBody::FileBody']]],
  ['from_1',['From',['../class_agora_chat_1_1_fetch_server_messages_option.html#afd342bbce88a0ad453158d70e4c9ee46',1,'AgoraChat.FetchServerMessagesOption.From()'],['../class_agora_chat_1_1_message.html#a9d354454d3ab0332b24618349062517f',1,'AgoraChat.Message.From()']]]
];
