var searchData=
[
  ['id_0',['Id',['../class_agora_chat_1_1_conversation.html#aa1f61f225fbe590ad64daee69ac184a8',1,'AgoraChat::Conversation']]],
  ['import_1',['IMPort',['../class_agora_chat_1_1_options.html#a6d549b8834f431b5123b35740414c0ef',1,'AgoraChat::Options']]],
  ['imserver_2',['IMServer',['../class_agora_chat_1_1_options.html#a5c1d151c3b68f93aed93a378276d35cd',1,'AgoraChat::Options']]],
  ['includesendmessageinmessagelistener_3',['IncludeSendMessageInMessageListener',['../class_agora_chat_1_1_options.html#a06041319058cf74b4c162ca05501af95',1,'AgoraChat::Options']]],
  ['inviteneedconfirm_4',['InviteNeedConfirm',['../class_agora_chat_1_1_group_options.html#aeae3e209a5d624b2fba85f70d3de92b5',1,'AgoraChat::GroupOptions']]],
  ['isautodownload_5',['IsAutoDownload',['../class_agora_chat_1_1_options.html#aa5f089dbda6f4e8d0ff6555fa3c69226',1,'AgoraChat::Options']]],
  ['iscontentreplaced_6',['IsContentReplaced',['../class_agora_chat_1_1_message.html#a23a54421c0563f619265ea6eed2bd53a',1,'AgoraChat::Message']]],
  ['isneedgroupack_7',['IsNeedGroupAck',['../class_agora_chat_1_1_message.html#a36fbb00a7101a428d8a02c25f2cf3da1',1,'AgoraChat::Message']]],
  ['ispinned_8',['IsPinned',['../class_agora_chat_1_1_conversation.html#a941607cb3301525d2e479b13f4e0c799',1,'AgoraChat::Conversation']]],
  ['isread_9',['IsRead',['../class_agora_chat_1_1_message.html#a1eaac37e72fbdc9864ce99b3bd1e6b67',1,'AgoraChat::Message']]],
  ['isroomownerleaveallowed_10',['IsRoomOwnerLeaveAllowed',['../class_agora_chat_1_1_options.html#ad5786f9a4803ca04a16fd22a472b565f',1,'AgoraChat::Options']]],
  ['issave_11',['IsSave',['../class_agora_chat_1_1_fetch_server_messages_option.html#af1400945375978c92d265120bf431b16',1,'AgoraChat::FetchServerMessagesOption']]],
  ['isthread_12',['IsThread',['../class_agora_chat_1_1_conversation.html#a77d4d24a8c27ea68ea324007d67d2722',1,'AgoraChat.Conversation.IsThread()'],['../class_agora_chat_1_1_message.html#ac874c62ac5475dc4c32af2b2cfcc6454',1,'AgoraChat.Message.IsThread()']]]
];
