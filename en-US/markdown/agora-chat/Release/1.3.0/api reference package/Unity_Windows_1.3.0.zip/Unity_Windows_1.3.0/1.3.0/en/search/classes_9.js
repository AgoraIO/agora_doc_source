var searchData=
[
  ['pageresult_0',['PageResult',['../class_agora_chat_1_1_page_result.html',1,'AgoraChat']]],
  ['pinnedinfo_1',['PinnedInfo',['../class_agora_chat_1_1_pinned_info.html',1,'AgoraChat']]],
  ['presence_2',['Presence',['../class_agora_chat_1_1_presence.html',1,'AgoraChat']]],
  ['presencedevicestatus_3',['PresenceDeviceStatus',['../class_agora_chat_1_1_presence_device_status.html',1,'AgoraChat']]],
  ['presencemanager_4',['PresenceManager',['../class_agora_chat_1_1_presence_manager.html',1,'AgoraChat']]]
];
