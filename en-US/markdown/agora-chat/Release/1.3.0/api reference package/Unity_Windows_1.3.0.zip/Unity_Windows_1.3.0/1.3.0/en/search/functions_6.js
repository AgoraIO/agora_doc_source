var searchData=
[
  ['imagebody_0',['ImageBody',['../class_agora_chat_1_1_message_body_1_1_image_body.html#a05a889100c00c89601934859bfb5fc2c',1,'AgoraChat::MessageBody::ImageBody']]],
  ['importmessages_1',['ImportMessages',['../class_agora_chat_1_1_chat_manager.html#a6259670ab78ecbeec5f5b4c72848e9e0',1,'AgoraChat::ChatManager']]],
  ['initwithoptions_2',['InitWithOptions',['../class_agora_chat_1_1_s_d_k_client.html#aab716d5121a18e495f042ad15ca66e79',1,'AgoraChat::SDKClient']]],
  ['insertmessage_3',['InsertMessage',['../class_agora_chat_1_1_conversation.html#a57e11967f955d5995707a948f21bab6a',1,'AgoraChat::Conversation']]]
];
