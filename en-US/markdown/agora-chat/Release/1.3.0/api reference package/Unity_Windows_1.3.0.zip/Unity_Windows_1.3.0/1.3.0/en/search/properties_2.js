var searchData=
[
  ['chatmanager_0',['ChatManager',['../class_agora_chat_1_1_s_d_k_client.html#a3e0976d42c6089bafd403a78b39164b5',1,'AgoraChat::SDKClient']]],
  ['chatthread_1',['ChatThread',['../class_agora_chat_1_1_chat_thread_event.html#a692ec3775b8b5f89a3ba03a9f81a1187',1,'AgoraChat.ChatThreadEvent.ChatThread()'],['../class_agora_chat_1_1_message.html#a07b7531c8dd9fbd60d5e1085bb267db2',1,'AgoraChat.Message.ChatThread()']]],
  ['code_2',['Code',['../class_agora_chat_1_1_error.html#ad308ca2652403b5734d2050fa26a9685',1,'AgoraChat::Error']]],
  ['contactmanager_3',['ContactManager',['../class_agora_chat_1_1_s_d_k_client.html#a5c530405f3c5fee875ff59a884266529',1,'AgoraChat::SDKClient']]],
  ['content_4',['Content',['../class_agora_chat_1_1_group_read_ack.html#ad50d48c7c20dfd338c584d4908665fa2',1,'AgoraChat::GroupReadAck']]],
  ['count_5',['Count',['../class_agora_chat_1_1_group_read_ack.html#adf6451b168a098aac09a6022b79d6ff3',1,'AgoraChat::GroupReadAck']]],
  ['createtime_6',['CreateTime',['../class_agora_chat_1_1_group_shared_file.html#ab785c931afcf7706b67c1f16c351312a',1,'AgoraChat::GroupSharedFile']]],
  ['currentusername_7',['CurrentUsername',['../class_agora_chat_1_1_s_d_k_client.html#a7e014e5629c9b00bc3c267855e4d3b7f',1,'AgoraChat::SDKClient']]],
  ['cursor_8',['Cursor',['../class_agora_chat_1_1_cursor_result.html#a72f343f96e6de7558705b45d80346b16',1,'AgoraChat::CursorResult']]]
];
