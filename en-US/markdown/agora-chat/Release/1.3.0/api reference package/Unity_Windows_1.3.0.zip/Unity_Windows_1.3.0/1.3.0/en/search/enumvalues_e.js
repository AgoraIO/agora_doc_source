var searchData=
[
  ['pending_0',['PENDING',['../namespace_agora_chat_1_1_message_body.html#a1c68f57689f3139b999693c8fec4546aac69f06e1a9b016d133907b4e5f5864d2',1,'AgoraChat::MessageBody']]],
  ['privatemembercaninvite_1',['PrivateMemberCanInvite',['../namespace_agora_chat.html#a78c8dcc8960a647beb75fb8dd1ebfa1ca0c8440eea815539a303c6fd2e13a43b5',1,'AgoraChat']]],
  ['privateonlyownerinvite_2',['PrivateOnlyOwnerInvite',['../namespace_agora_chat.html#a78c8dcc8960a647beb75fb8dd1ebfa1cab7972563204619b46325c42085fbf966',1,'AgoraChat']]],
  ['progress_3',['PROGRESS',['../namespace_agora_chat.html#a33be8ac1aa48dbbed69d5a7f40ffb131aee88634543eb5c2b123bab1abd32c497',1,'AgoraChat']]],
  ['publicjoinneedapproval_4',['PublicJoinNeedApproval',['../namespace_agora_chat.html#a78c8dcc8960a647beb75fb8dd1ebfa1ca142af479e670a52cc352878005123164',1,'AgoraChat']]],
  ['publicopenjoin_5',['PublicOpenJoin',['../namespace_agora_chat.html#a78c8dcc8960a647beb75fb8dd1ebfa1caef55941d4eb818852baf30de41820b9a',1,'AgoraChat']]]
];
