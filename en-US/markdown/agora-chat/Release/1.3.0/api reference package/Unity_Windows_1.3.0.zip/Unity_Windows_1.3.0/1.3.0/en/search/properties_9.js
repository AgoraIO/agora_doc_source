var searchData=
[
  ['maxusercount_0',['MaxUserCount',['../class_agora_chat_1_1_group.html#ada18795fc1bb6eba93768b51e87994e9',1,'AgoraChat::Group']]],
  ['maxusers_1',['MaxUsers',['../class_agora_chat_1_1_room.html#a01876f6cc7bfebb72e1da2803937df66',1,'AgoraChat::Room']]],
  ['membercount_2',['MemberCount',['../class_agora_chat_1_1_group.html#ae7a461132f05c746b01bd1959ff5a51e',1,'AgoraChat.Group.MemberCount()'],['../class_agora_chat_1_1_room.html#aecb463bd80a7aa393348e55140b65e08',1,'AgoraChat.Room.MemberCount()']]],
  ['memberlist_3',['MemberList',['../class_agora_chat_1_1_group.html#ae3d8f54431bfd527029484289f4d1f80',1,'AgoraChat.Group.MemberList()'],['../class_agora_chat_1_1_room.html#a96c75c9b229a47fcc2e4258568880c66',1,'AgoraChat.Room.MemberList()']]],
  ['messageblocked_4',['MessageBlocked',['../class_agora_chat_1_1_group.html#af1e13ab6fd0d7b3029ccde47fe44e902',1,'AgoraChat::Group']]],
  ['msgid_5',['MsgId',['../class_agora_chat_1_1_group_read_ack.html#aacb026285f6dfc5deb996cfe1ddb37f2',1,'AgoraChat::GroupReadAck']]],
  ['mutelist_6',['MuteList',['../class_agora_chat_1_1_group.html#a22db19d6c43fa2ad1dfc21cdfdd3259b',1,'AgoraChat.Group.MuteList()'],['../class_agora_chat_1_1_room.html#aea2cc1a952d7600ec8bcab6856a46601',1,'AgoraChat.Room.MuteList()']]]
];
