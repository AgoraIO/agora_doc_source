var searchData=
[
  ['admin_0',['Admin',['../namespace_agora_chat.html#ad237b6d2eb1d74494a9edf19c66fed61ae3afed0047b08059d0fada10f400c1e5',1,'AgoraChat.Admin()'],['../namespace_agora_chat.html#a2b6f39a7c115fd66eb10ef26f8c9cb76ae3afed0047b08059d0fada10f400c1e5',1,'AgoraChat.Admin()']]],
  ['all_1',['ALL',['../namespace_agora_chat.html#a5b46368751bc6fc3ba812aa433030fc1a5fb1f955b45e38e31789286a1790398d',1,'AgoraChat']]]
];
