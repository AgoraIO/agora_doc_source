var searchData=
[
  ['data_0',['Data',['../class_agora_chat_1_1_cursor_result.html#ad39a880e3956c3a5fe14802468c8f914',1,'AgoraChat.CursorResult.Data()'],['../class_agora_chat_1_1_page_result.html#a52f834a649e1dbab8692a130215fb46e',1,'AgoraChat.PageResult.Data()']]],
  ['desc_1',['Desc',['../class_agora_chat_1_1_error.html#a75fa56034d4068833977ad7a93ff7df2',1,'AgoraChat::Error']]],
  ['description_2',['Description',['../class_agora_chat_1_1_group.html#adb55e63516ac5601d2d49116dcb1a2c2',1,'AgoraChat.Group.Description()'],['../class_agora_chat_1_1_room.html#a3721c860efc81a811ba7ca19e9ceae15',1,'AgoraChat.Room.Description()']]],
  ['devicename_3',['DeviceName',['../class_agora_chat_1_1_device_info.html#a7930f7d0c04fa370a25e3e188e8cbbc0',1,'AgoraChat::DeviceInfo']]],
  ['deviceuuid_4',['DeviceUUID',['../class_agora_chat_1_1_device_info.html#a8f58e1efa4e7482979181ad994b06c8a',1,'AgoraChat::DeviceInfo']]]
];
