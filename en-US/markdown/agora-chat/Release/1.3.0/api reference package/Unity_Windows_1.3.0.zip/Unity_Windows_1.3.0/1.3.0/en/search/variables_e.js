var searchData=
[
  ['reaction_0',['Reaction',['../class_agora_chat_1_1_message_reaction.html#a057d406d9057ef09766c6da5943998c2',1,'AgoraChat.MessageReaction.Reaction()'],['../class_agora_chat_1_1_message_reaction_operation.html#abcec0db5067175e3825cabd2cac6c3d4',1,'AgoraChat.MessageReactionOperation.Reaction()']]],
  ['reactionlist_1',['ReactionList',['../class_agora_chat_1_1_message_reaction_change.html#a50ea53aafeb77c3013710753e81daf15',1,'AgoraChat::MessageReactionChange']]],
  ['regardimportmsgasread_2',['RegardImportMsgAsRead',['../class_agora_chat_1_1_options.html#a59180920f36913b4d098994d823331f9',1,'AgoraChat::Options']]],
  ['remotepath_3',['RemotePath',['../class_agora_chat_1_1_message_body_1_1_file_body.html#a418859babf1f8dcf3b26ea6462d53180',1,'AgoraChat::MessageBody::FileBody']]],
  ['requireack_4',['RequireAck',['../class_agora_chat_1_1_options.html#ada0e487b42c148132ec58b0cc93bf553',1,'AgoraChat::Options']]],
  ['requiredeliveryack_5',['RequireDeliveryAck',['../class_agora_chat_1_1_options.html#a135f01154b475952b6fce035b9c8a4ca',1,'AgoraChat::Options']]],
  ['restserver_6',['RestServer',['../class_agora_chat_1_1_options.html#ad7d17660c9b09866cbef29bac64edb46',1,'AgoraChat::Options']]]
];
