var searchData=
[
  ['sdkclient_0',['SDKClient',['../class_agora_chat_1_1_s_d_k_client.html',1,'AgoraChat']]],
  ['supportlanguage_1',['SupportLanguage',['../class_agora_chat_1_1_support_language.html',1,'AgoraChat']]]
];
