var searchData=
[
  ['searchmsgfromdb_0',['SearchMsgFromDB',['../class_agora_chat_1_1_chat_manager.html#ab6b2afccac3d5e8e1daf33abb0c2f3af',1,'AgoraChat.ChatManager.SearchMsgFromDB(string keywords, long timestamp=0, int maxCount=20, string from=null, MessageSearchDirection direction=MessageSearchDirection.UP, ValueCallBack&lt; List&lt; Message &gt; &gt; callback=null)'],['../class_agora_chat_1_1_chat_manager.html#a10052ded922daaa078a3818cc9925c80',1,'AgoraChat.ChatManager.SearchMsgFromDB(string keywords, long timestamp=0, int maxCount=20, string from=null, MessageSearchDirection direction=MessageSearchDirection.UP, MessageSearchScope scope=MessageSearchScope.CONTENT, ValueCallBack&lt; List&lt; Message &gt; &gt; callback=null)']]],
  ['sendconversationreadack_1',['SendConversationReadAck',['../class_agora_chat_1_1_chat_manager.html#a0253a40f83cc6c9805067621e0d7c818',1,'AgoraChat::ChatManager']]],
  ['sendmessage_2',['SendMessage',['../class_agora_chat_1_1_chat_manager.html#af9f598e16100bebd4b035d8335262e2b',1,'AgoraChat::ChatManager']]],
  ['sendmessagereadack_3',['SendMessageReadAck',['../class_agora_chat_1_1_chat_manager.html#af9cca4dff53384c723789d3fda294238',1,'AgoraChat::ChatManager']]],
  ['sendreadackforgroupmessage_4',['SendReadAckForGroupMessage',['../class_agora_chat_1_1_chat_manager.html#a4da90d42232684a08d5e95d8251812b3',1,'AgoraChat::ChatManager']]],
  ['setattribute_5',['SetAttribute',['../class_agora_chat_1_1_message.html#a68bf990a3120b2209e34f1c022993251',1,'AgoraChat::Message']]],
  ['setcontactremark_6',['SetContactRemark',['../class_agora_chat_1_1_contact_manager.html#a28273da38d6a23c73b9c74f6eb07eef4',1,'AgoraChat::ContactManager']]],
  ['setmemberattributes_7',['SetMemberAttributes',['../class_agora_chat_1_1_group_manager.html#ad10020882ad1f6ed528f9c29703f7a20',1,'AgoraChat::GroupManager']]],
  ['setroommessagepriority_8',['SetRoomMessagePriority',['../class_agora_chat_1_1_message.html#ade07d43948f84110075013bb67df4cc1',1,'AgoraChat::Message']]],
  ['subscribepresences_9',['SubscribePresences',['../class_agora_chat_1_1_presence_manager.html#a45d352f595e5f8fcabfaa1a8650cc5a0',1,'AgoraChat::PresenceManager']]]
];
