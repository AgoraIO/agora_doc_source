var searchData=
[
  ['name_0',['Name',['../class_agora_chat_1_1_chat_thread.html#a984fa46098c08803a2f6e57e4e6b9c98',1,'AgoraChat::ChatThread']]],
  ['nickname_1',['NickName',['../class_agora_chat_1_1_user_info.html#a55e54746b776f66896ff6d025fc501ae',1,'AgoraChat::UserInfo']]]
];
