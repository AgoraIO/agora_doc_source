var searchData=
[
  ['debugmode_0',['DebugMode',['../class_agora_chat_1_1_options.html#a1b82e864c6b8934462976da2202e23aa',1,'AgoraChat::Options']]],
  ['deletemessagesasexitgroup_1',['DeleteMessagesAsExitGroup',['../class_agora_chat_1_1_options.html#ae2fac4ac8dd73403fae1b17b6767bbcc',1,'AgoraChat::Options']]],
  ['deletemessagesasexitroom_2',['DeleteMessagesAsExitRoom',['../class_agora_chat_1_1_options.html#a127bae507502c98692d598758c24e9c3',1,'AgoraChat::Options']]],
  ['deliveronlineonly_3',['DeliverOnlineOnly',['../class_agora_chat_1_1_message.html#ae67831eb3569c19ab09fa42b9706dfbb',1,'AgoraChat.Message.DeliverOnlineOnly()'],['../class_agora_chat_1_1_message_body_1_1_cmd_body.html#a675523723b0d5befad09bf652b5e24fe',1,'AgoraChat.MessageBody.CmdBody.DeliverOnlineOnly()']]],
  ['deviceid_4',['DeviceId',['../class_agora_chat_1_1_presence_device_status.html#a0770552435a0cc7c5845744fdf8b77d4',1,'AgoraChat::PresenceDeviceStatus']]],
  ['direction_5',['Direction',['../class_agora_chat_1_1_fetch_server_messages_option.html#af36ae8baae469ae7dfc14a7f85946ed8',1,'AgoraChat.FetchServerMessagesOption.Direction()'],['../class_agora_chat_1_1_message.html#a54bb76176117b6e0a6a0f36b2724afb5',1,'AgoraChat.Message.Direction()']]],
  ['displayname_6',['DisplayName',['../class_agora_chat_1_1_message_body_1_1_file_body.html#a24caea73344b78cb01770e0931491153',1,'AgoraChat::MessageBody::FileBody']]],
  ['dnsurl_7',['DNSURL',['../class_agora_chat_1_1_options.html#a83cbce86244d6c8d2138af13db36e4e0',1,'AgoraChat::Options']]],
  ['downstatus_8',['DownStatus',['../class_agora_chat_1_1_message_body_1_1_file_body.html#a92379255b6415f6f610d771c0302919b',1,'AgoraChat::MessageBody::FileBody']]],
  ['duration_9',['Duration',['../class_agora_chat_1_1_message_body_1_1_voice_body.html#a425391146f7e869c64e23940a09d4049',1,'AgoraChat.MessageBody.VoiceBody.Duration()'],['../class_agora_chat_1_1_message_body_1_1_video_body.html#a15db0d7ff7b80d14bd8c1c4af5b782d3',1,'AgoraChat.MessageBody.VideoBody.Duration()']]]
];
