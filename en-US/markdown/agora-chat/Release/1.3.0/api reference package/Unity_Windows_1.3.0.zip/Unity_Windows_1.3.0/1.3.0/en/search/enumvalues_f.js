var searchData=
[
  ['reason_5fauthenticationfailed_0',['Reason_AuthenticationFailed',['../namespace_agora_chat.html#a6ea0ad2821d94a452a3406880e6bcfb0acd9f2b56f021a79760b726cb5c07816a',1,'AgoraChat']]],
  ['reason_5fchangepassword_1',['Reason_ChangePassword',['../namespace_agora_chat.html#a6ea0ad2821d94a452a3406880e6bcfb0a295fb946a615ec14589a3c78fce431da',1,'AgoraChat']]],
  ['reason_5fdisconnected_2',['Reason_Disconnected',['../namespace_agora_chat.html#a6ea0ad2821d94a452a3406880e6bcfb0a1bccc83e19ec7438f7f0973ca93734ef',1,'AgoraChat']]],
  ['reason_5fforbidbyserver_3',['Reason_ForbidByServer',['../namespace_agora_chat.html#a6ea0ad2821d94a452a3406880e6bcfb0aad073691bf676b3660549d93bda8cbb0',1,'AgoraChat']]],
  ['reason_5fkickedbyotherdevice_4',['Reason_KickedByOtherDevice',['../namespace_agora_chat.html#a6ea0ad2821d94a452a3406880e6bcfb0a941b145d76f4c5dba09cfcae2c391509',1,'AgoraChat']]],
  ['reason_5floginfromotherdevice_5',['Reason_LoginFromOtherDevice',['../namespace_agora_chat.html#a6ea0ad2821d94a452a3406880e6bcfb0a89cb97230af0638f7159c8f69b4e0af5',1,'AgoraChat']]],
  ['reason_5flogintoomanydevice_6',['Reason_LoginTooManyDevice',['../namespace_agora_chat.html#a6ea0ad2821d94a452a3406880e6bcfb0a0dac491d6a6115d711912b79a10639e9',1,'AgoraChat']]],
  ['reason_5fremovefromserver_7',['Reason_RemoveFromServer',['../namespace_agora_chat.html#a6ea0ad2821d94a452a3406880e6bcfb0a048a702043f1ed497f7431189447d387',1,'AgoraChat']]],
  ['receive_8',['RECEIVE',['../namespace_agora_chat.html#ac17636c7a7b633f9c185876d850a44eea42ddaaef1ffd16ad35901150add8f8f2',1,'AgoraChat']]],
  ['room_9',['Room',['../namespace_agora_chat.html#abebfeb274ae77efacf1738a6c9733dabacc3abcf4426bff80257d22999d0eda8f',1,'AgoraChat.Room()'],['../namespace_agora_chat.html#ad281aa6e4c993e9daf9361c5eb87bc22acc3abcf4426bff80257d22999d0eda8f',1,'AgoraChat.Room()']]]
];
