var searchData=
[
  ['accesstoken_0',['AccessToken',['../class_agora_chat_1_1_s_d_k_client.html#a11ac9f4c5a2832af918c29c9607cb9e9',1,'AgoraChat::SDKClient']]],
  ['ackid_1',['AckId',['../class_agora_chat_1_1_group_read_ack.html#a3636ff2c546c8a33380a58d20c8004db',1,'AgoraChat::GroupReadAck']]],
  ['adminlist_2',['AdminList',['../class_agora_chat_1_1_group.html#a18d5c62b6be5d25011423742c4c31b33',1,'AgoraChat.Group.AdminList()'],['../class_agora_chat_1_1_room.html#accc32f8fc3756ff32e3d12424035dcef',1,'AgoraChat.Room.AdminList()']]],
  ['announcement_3',['Announcement',['../class_agora_chat_1_1_group.html#a0a228d2800190d7d8235ab6cf6dd9cab',1,'AgoraChat.Group.Announcement()'],['../class_agora_chat_1_1_room.html#ae66cb3637ac5c35418667bde349db019',1,'AgoraChat.Room.Announcement()']]]
];
