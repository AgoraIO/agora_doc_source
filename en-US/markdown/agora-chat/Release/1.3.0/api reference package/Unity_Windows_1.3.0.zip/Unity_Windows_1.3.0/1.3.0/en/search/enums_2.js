var searchData=
[
  ['disconnectreason_0',['DisconnectReason',['../namespace_agora_chat.html#a6ea0ad2821d94a452a3406880e6bcfb0',1,'AgoraChat']]],
  ['downloadstatus_1',['DownLoadStatus',['../namespace_agora_chat_1_1_message_body.html#a1c68f57689f3139b999693c8fec4546a',1,'AgoraChat::MessageBody']]]
];
