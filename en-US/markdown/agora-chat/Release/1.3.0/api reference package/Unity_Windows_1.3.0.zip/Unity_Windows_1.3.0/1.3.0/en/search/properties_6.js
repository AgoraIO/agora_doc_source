var searchData=
[
  ['groupackcount_0',['GroupAckCount',['../class_agora_chat_1_1_message.html#a321681ad0687a1e151f2acc26cfc7b13',1,'AgoraChat::Message']]],
  ['groupid_1',['GroupId',['../class_agora_chat_1_1_group.html#a85b60c8699ce50cccf44398aa60285a1',1,'AgoraChat.Group.GroupId()'],['../class_agora_chat_1_1_group_info.html#a7b0917dc50e27a69ada765e3031f5d5e',1,'AgoraChat.GroupInfo.GroupId()']]],
  ['groupmanager_2',['GroupManager',['../class_agora_chat_1_1_s_d_k_client.html#a1c0e8c344f4c197c7cfb75659ab90ba9',1,'AgoraChat::SDKClient']]],
  ['groupname_3',['GroupName',['../class_agora_chat_1_1_group_info.html#a7de55c2a56aa6b4d3f8c97a2087ea02a',1,'AgoraChat::GroupInfo']]]
];
