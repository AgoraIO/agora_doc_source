var searchData=
[
  ['owner_0',['Owner',['../namespace_agora_chat.html#ad237b6d2eb1d74494a9edf19c66fed61ab6f4a2ec6356bbd56d49f2096bf9d3d3',1,'AgoraChat.Owner()'],['../namespace_agora_chat.html#a2b6f39a7c115fd66eb10ef26f8c9cb76ab6f4a2ec6356bbd56d49f2096bf9d3d3',1,'AgoraChat.Owner()']]]
];
