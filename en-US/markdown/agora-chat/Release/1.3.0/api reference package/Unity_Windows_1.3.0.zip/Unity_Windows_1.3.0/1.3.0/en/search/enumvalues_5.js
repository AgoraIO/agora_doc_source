var searchData=
[
  ['fail_0',['FAIL',['../namespace_agora_chat.html#a33be8ac1aa48dbbed69d5a7f40ffb131ac2759effffc94bb9acc71d69fe3e8a1f',1,'AgoraChat']]],
  ['failed_1',['FAILED',['../namespace_agora_chat_1_1_message_body.html#a1c68f57689f3139b999693c8fec4546aab9e14d9b2886bcff408b85aefa780419',1,'AgoraChat::MessageBody']]],
  ['file_2',['FILE',['../namespace_agora_chat.html#a8d167e073ca67f4f12657a2dde388df1a9fc5887c030f7a3e19821ebec457e719',1,'AgoraChat']]],
  ['float_3',['FLOAT',['../namespace_agora_chat.html#a292bc538f956ba5bf2976941df4b469bae738c26bf4ce1037fa81b039a915cbf6',1,'AgoraChat']]]
];
