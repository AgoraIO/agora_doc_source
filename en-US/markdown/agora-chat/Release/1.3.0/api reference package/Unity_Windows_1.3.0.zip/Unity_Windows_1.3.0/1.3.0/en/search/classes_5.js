var searchData=
[
  ['ichatmanagerdelegate_0',['IChatManagerDelegate',['../interface_agora_chat_1_1_i_chat_manager_delegate.html',1,'AgoraChat']]],
  ['ichatthreadmanagerdelegate_1',['IChatThreadManagerDelegate',['../interface_agora_chat_1_1_i_chat_thread_manager_delegate.html',1,'AgoraChat']]],
  ['iconnectiondelegate_2',['IConnectionDelegate',['../interface_agora_chat_1_1_i_connection_delegate.html',1,'AgoraChat']]],
  ['icontactmanagerdelegate_3',['IContactManagerDelegate',['../interface_agora_chat_1_1_i_contact_manager_delegate.html',1,'AgoraChat']]],
  ['igroupmanagerdelegate_4',['IGroupManagerDelegate',['../interface_agora_chat_1_1_i_group_manager_delegate.html',1,'AgoraChat']]],
  ['imagebody_5',['ImageBody',['../class_agora_chat_1_1_message_body_1_1_image_body.html',1,'AgoraChat::MessageBody']]],
  ['imessagebody_6',['IMessageBody',['../class_agora_chat_1_1_i_message_body.html',1,'AgoraChat']]],
  ['imultidevicedelegate_7',['IMultiDeviceDelegate',['../interface_agora_chat_1_1_i_multi_device_delegate.html',1,'AgoraChat']]],
  ['ipresencemanagerdelegate_8',['IPresenceManagerDelegate',['../interface_agora_chat_1_1_i_presence_manager_delegate.html',1,'AgoraChat']]],
  ['iroommanagerdelegate_9',['IRoomManagerDelegate',['../interface_agora_chat_1_1_i_room_manager_delegate.html',1,'AgoraChat']]]
];
