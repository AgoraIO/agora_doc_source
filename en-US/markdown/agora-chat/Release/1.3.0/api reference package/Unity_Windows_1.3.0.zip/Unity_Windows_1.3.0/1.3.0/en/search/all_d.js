var searchData=
[
  ['name_0',['Name',['../class_agora_chat_1_1_chat_thread.html#a984fa46098c08803a2f6e57e4e6b9c98',1,'AgoraChat.ChatThread.Name()'],['../class_agora_chat_1_1_group.html#a73c4c1d90695a9fd34e4a8d897b69f54',1,'AgoraChat.Group.Name()'],['../class_agora_chat_1_1_room.html#a3dcd7990b14caf48df39eeef0b6ee72b',1,'AgoraChat.Room.Name()']]],
  ['nickname_1',['NickName',['../class_agora_chat_1_1_user_info.html#a55e54746b776f66896ff6d025fc501ae',1,'AgoraChat::UserInfo']]],
  ['normal_2',['Normal',['../namespace_agora_chat.html#aa6d032a78afa107bfed3ea28009b5ff7a960b44c579bc2f6818d2daaf9e4c16f0',1,'AgoraChat']]],
  ['noticeenabled_3',['NoticeEnabled',['../class_agora_chat_1_1_group.html#aedc23cc6bdff12f0d3f7b6752bebdcf9',1,'AgoraChat::Group']]]
];
