var searchData=
[
  ['blockgroup_0',['BlockGroup',['../class_agora_chat_1_1_group_manager.html#a63fa55e7c57831fa54d5e8e716cfabb5',1,'AgoraChat::GroupManager']]],
  ['blockgroupmembers_1',['BlockGroupMembers',['../class_agora_chat_1_1_group_manager.html#a4a724345647afadb39f43aa1724e77db',1,'AgoraChat::GroupManager']]],
  ['blockroommembers_2',['BlockRoomMembers',['../class_agora_chat_1_1_room_manager.html#a02097b33464e047003d5b6de0e3088d3',1,'AgoraChat::RoomManager']]]
];
