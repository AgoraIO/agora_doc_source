var searchData=
[
  ['video_0',['VIDEO',['../enumio_1_1agora_1_1chat_1_1_chat_message_1_1_type.html#a9fc27b8f1d10ddf6f9736ee81d9d2873',1,'io.agora.chat.ChatMessage.Type.VIDEO()'],['../enumio_1_1agora_1_1chat_1_1_chat_statistics_manager_1_1_search_message_type.html#a7ef69f5e72b9173bdb72ce3ed1d8bd70',1,'io.agora.chat.ChatStatisticsManager.SearchMessageType.VIDEO()']]],
  ['vivopush_1',['VIVOPUSH',['../enumio_1_1agora_1_1push_1_1_push_type.html#ae0657e7b5e5458d3c630bfc7867c37ad',1,'io::agora::push::PushType']]],
  ['voice_2',['VOICE',['../enumio_1_1agora_1_1chat_1_1_chat_message_1_1_type.html#af5b0f599e78df5cb65a377de82533320',1,'io.agora.chat.ChatMessage.Type.VOICE()'],['../enumio_1_1agora_1_1chat_1_1_chat_statistics_manager_1_1_search_message_type.html#acee52d68ed34df4033ebb973e86ec7ee',1,'io.agora.chat.ChatStatisticsManager.SearchMessageType.VOICE()']]]
];
