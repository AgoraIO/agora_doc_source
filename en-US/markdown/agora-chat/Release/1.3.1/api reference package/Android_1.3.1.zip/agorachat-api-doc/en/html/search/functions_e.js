var searchData=
[
  ['pinnedinfo_0',['pinnedInfo',['../classio_1_1agora_1_1chat_1_1_chat_message.html#a7fe49d1581c1b153645d3272742eadba',1,'io::agora::chat::ChatMessage']]],
  ['pinnedmessages_1',['pinnedMessages',['../classio_1_1agora_1_1chat_1_1_conversation.html#aad38344eaf166a878f6d974abd16b8ea',1,'io::agora::chat::Conversation']]],
  ['pintime_2',['pinTime',['../classio_1_1agora_1_1chat_1_1_message_pin_info.html#a933d6b8fb0c9dfb03f2f95a82c57f28f',1,'io::agora::chat::MessagePinInfo']]],
  ['progress_3',['progress',['../classio_1_1agora_1_1chat_1_1_chat_message.html#a84861ae86203b2ef695969e47cb4360e',1,'io::agora::chat::ChatMessage']]],
  ['publishpresence_4',['publishPresence',['../classio_1_1agora_1_1chat_1_1_presence_manager.html#a47ff923b5496049fcf34e2dd405fadd8',1,'io::agora::chat::PresenceManager']]],
  ['pushmanager_5',['pushManager',['../classio_1_1agora_1_1chat_1_1_chat_client.html#a5ccbb31695c3c13b82f797015d7d7d0b',1,'io::agora::chat::ChatClient']]],
  ['pushremindtype_6',['pushRemindType',['../classio_1_1agora_1_1chat_1_1_conversation.html#aaccb2ec64484fcc3486b090a05bcb6f9',1,'io::agora::chat::Conversation']]]
];
