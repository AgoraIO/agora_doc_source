var searchData=
[
  ['normalfilemessagebody_0',['NormalFileMessageBody',['../classio_1_1agora_1_1chat_1_1_normal_file_message_body.html#a553f3e89b0e9fe15cf20198f8326408a',1,'io.agora.chat.NormalFileMessageBody.NormalFileMessageBody(File file)'],['../classio_1_1agora_1_1chat_1_1_normal_file_message_body.html#a6c391bc48fcaaae4e74956f6b06b26d2',1,'io.agora.chat.NormalFileMessageBody.NormalFileMessageBody(Uri localPath)']]],
  ['notifytokenexpired_1',['notifyTokenExpired',['../classio_1_1agora_1_1chat_1_1_chat_client.html#a1e2c0febc0a96775a609cb3c52bcea15',1,'io::agora::chat::ChatClient']]]
];
