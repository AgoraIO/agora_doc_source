var searchData=
[
  ['database_5ferror_0',['DATABASE_ERROR',['../classio_1_1agora_1_1_error.html#a6138561d9c5d4948bd3069242072987a',1,'io::agora::Error']]],
  ['down_1',['DOWN',['../enumio_1_1agora_1_1chat_1_1_conversation_1_1_search_direction.html#ac245786890f592f0990e6ff53ba76318',1,'io::agora::chat::Conversation::SearchDirection']]]
];
