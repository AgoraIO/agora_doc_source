var searchData=
[
  ['textmessagebody_0',['TextMessageBody',['../classio_1_1agora_1_1chat_1_1_text_message_body.html',1,'io::agora::chat']]],
  ['type_1',['Type',['../enumio_1_1agora_1_1chat_1_1_chat_message_1_1_type.html',1,'io::agora::chat::ChatMessage']]]
];
