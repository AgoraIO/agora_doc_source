var searchData=
[
  ['locationmessagebody_0',['LocationMessageBody',['../classio_1_1agora_1_1chat_1_1_location_message_body.html',1,'io::agora::chat']]]
];
