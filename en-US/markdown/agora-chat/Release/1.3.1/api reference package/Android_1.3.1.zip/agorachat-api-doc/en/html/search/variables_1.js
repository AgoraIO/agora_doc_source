var searchData=
[
  ['be_5fkicked_0',['BE_KICKED',['../interfaceio_1_1agora_1_1_chat_room_change_listener.html#ab33aa3e17830603437abd43f81378de5',1,'io::agora::ChatRoomChangeListener']]],
  ['be_5fkicked_5ffor_5foffline_1',['BE_KICKED_FOR_OFFLINE',['../interfaceio_1_1agora_1_1_chat_room_change_listener.html#a008f80b599b824246cb0415a126a251f',1,'io::agora::ChatRoomChangeListener']]]
];
