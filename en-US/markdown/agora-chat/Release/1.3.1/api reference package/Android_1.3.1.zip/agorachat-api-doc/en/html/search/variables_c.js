var searchData=
[
  ['operation_5funsupported_0',['OPERATION_UNSUPPORTED',['../classio_1_1agora_1_1_error.html#aaa93c90d3110e4dafed3c329c8a41feb',1,'io::agora::Error']]],
  ['oppopush_1',['OPPOPUSH',['../enumio_1_1agora_1_1push_1_1_push_type.html#a6a0d9c2f66551bbc681cb8ece6ad5225',1,'io::agora::push::PushType']]],
  ['owner_2',['owner',['../enumio_1_1agora_1_1chat_1_1_chat_room_1_1_chat_room_permission_type.html#a42a77d9e14d443b053d818345a378021',1,'io.agora.chat.ChatRoom.ChatRoomPermissionType.owner()'],['../enumio_1_1agora_1_1chat_1_1_group_1_1_group_permission_type.html#a32dec665e3411ef7714f6ad41ff8d2b1',1,'io.agora.chat.Group.GroupPermissionType.owner()']]]
];
