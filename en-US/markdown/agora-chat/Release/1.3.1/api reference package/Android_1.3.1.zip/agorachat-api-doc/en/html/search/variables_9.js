var searchData=
[
  ['location_0',['LOCATION',['../enumio_1_1agora_1_1chat_1_1_chat_message_1_1_type.html#aa06f2dbd63f2a4a60f1ad178e9452963',1,'io.agora.chat.ChatMessage.Type.LOCATION()'],['../enumio_1_1agora_1_1chat_1_1_chat_statistics_manager_1_1_search_message_type.html#a01524fc9a183fb9273ba8b8b25e66049',1,'io.agora.chat.ChatStatisticsManager.SearchMessageType.LOCATION()']]]
];
