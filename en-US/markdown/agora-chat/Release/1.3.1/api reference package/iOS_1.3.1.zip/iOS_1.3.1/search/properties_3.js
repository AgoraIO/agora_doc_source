var searchData=
[
  ['deletemessagesonleavechatroom_0',['deleteMessagesOnLeaveChatroom',['../interface_agora_chat_options.html#ae7e7dc605cdce4bb81b59b7d3e3851c9',1,'AgoraChatOptions']]],
  ['deletemessagesonleavegroup_1',['deleteMessagesOnLeaveGroup',['../interface_agora_chat_options.html#a55da002396dbae75792f047bd6166f8d',1,'AgoraChatOptions']]],
  ['deliveronlineonly_2',['deliverOnlineOnly',['../interface_agora_chat_message.html#aa37f78501083216e022256e0ca80db45',1,'AgoraChatMessage']]],
  ['description_3',['description',['../interface_agora_chat_group.html#ac643a1d4075bd57fd29b846578314813',1,'AgoraChatGroup::description()'],['../interface_agora_chatroom.html#a3ea3ce69fa0ceeb4ca0faac12bf3513a',1,'AgoraChatroom::description()']]],
  ['device_4',['device',['../interface_agora_chat_presence_status_detail.html#a99090924ca69de2b1fd84509d39fafe5',1,'AgoraChatPresenceStatusDetail']]],
  ['devicename_5',['deviceName',['../interface_agora_chat_device_config.html#ac01940bcc1a83b344a27a00e332a7401',1,'AgoraChatDeviceConfig::deviceName()'],['../interface_agora_chat_login_extension_info.html#a02f47cbf5ba2b713de7319f0931e1707',1,'AgoraChatLoginExtensionInfo::deviceName()']]],
  ['deviceuuid_6',['deviceUUID',['../interface_agora_chat_device_config.html#a48954bbe40c60fc8d96ff6676b40c882',1,'AgoraChatDeviceConfig']]],
  ['direction_7',['direction',['../interface_agora_chat_fetch_server_messages_option.html#af70b981cd8962d76701f1aaccd056260',1,'AgoraChatFetchServerMessagesOption::direction()'],['../interface_agora_chat_message.html#a75f5c01e761a33c3158e7d6eb7c2f7e9',1,'AgoraChatMessage::direction()'],['../interface_agora_chat_message_statistics.html#a512e410e5fa70efcfa69f776fc0065d1',1,'AgoraChatMessageStatistics::direction()']]],
  ['displayname_8',['displayName',['../interface_agora_chat_file_message_body.html#a2f939e4d059fdf678a6b0fff3d1a8362',1,'AgoraChatFileMessageBody::displayName()'],['../interface_agora_chat_push_options.html#a682e0d0ff7c373aa8bdb3ea60ed63b23',1,'AgoraChatPushOptions::displayName()']]],
  ['displaystyle_9',['displayStyle',['../interface_agora_chat_push_options.html#a539e0254aa5fe1524f169cd24c05a281',1,'AgoraChatPushOptions']]],
  ['disturbtype_10',['disturbType',['../interface_agora_chat_conversation.html#a697df0972124ae1a7054d8d8c4f3f754',1,'AgoraChatConversation']]],
  ['dnsurl_11',['dnsURL',['../category_agora_chat_options_07_private_deploy_08.html#add63d92384d5fdf6c03abb388e193837',1,'AgoraChatOptions(PrivateDeploy)::dnsURL()'],['../interface_agora_chat_options.html#add63d92384d5fdf6c03abb388e193837',1,'AgoraChatOptions::dnsURL()']]],
  ['downloadstatus_12',['downloadStatus',['../interface_agora_chat_file_message_body.html#aaddffe29ecc9644fc6f6c49a8e5f541d',1,'AgoraChatFileMessageBody']]],
  ['duration_13',['duration',['../interface_agora_chat_video_message_body.html#a1613585e56874951c5c8859ad6f69dc5',1,'AgoraChatVideoMessageBody::duration()'],['../interface_agora_chat_voice_message_body.html#a6f7fb668be6328622563a637bb446be1',1,'AgoraChatVoiceMessageBody::duration()']]]
];
