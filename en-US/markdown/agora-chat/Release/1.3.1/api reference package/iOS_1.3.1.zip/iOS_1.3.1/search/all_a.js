var searchData=
[
  ['joinchatroom_3acompletion_3a_0',['joinChatroom:completion:',['../protocol_i_agora_chatroom_manager-p.html#ad8d19bd36e60c8af8d04c1f8b4daa2f0',1,'IAgoraChatroomManager-p']]],
  ['joinchatroom_3aerror_3a_1',['joinChatroom:error:',['../protocol_i_agora_chatroom_manager-p.html#a770dc60aec5e41ad7a1dea47e0bcae23',1,'IAgoraChatroomManager-p']]],
  ['joinchatroom_3aext_3aleaveotherrooms_3acompletion_3a_2',['joinChatroom:ext:leaveOtherRooms:completion:',['../protocol_i_agora_chatroom_manager-p.html#a391976ba14d9766bf5ae3b0266572113',1,'IAgoraChatroomManager-p']]],
  ['joinchatthread_3acompletion_3a_3',['joinChatThread:completion:',['../protocol_i_agora_chat_thread_manager-p.html#a65e121025668162c93dbf66b2b9d3b82',1,'IAgoraChatThreadManager-p']]],
  ['joingrouprequestdidapprove_3a_4',['joinGroupRequestDidApprove:',['../protocol_agora_chat_group_manager_delegate-p.html#a4df1cc1abe6ef12f1bcf74b2520d6dbe',1,'AgoraChatGroupManagerDelegate-p']]],
  ['joingrouprequestdiddecline_3areason_3a_5',['joinGroupRequestDidDecline:reason:',['../protocol_agora_chat_group_manager_delegate-p.html#aed1681123793e2d79a7d6200664f53e5',1,'AgoraChatGroupManagerDelegate-p']]],
  ['joingrouprequestdiddecline_3areason_3aapplicant_3a_6',['joinGroupRequestDidDecline:reason:applicant:',['../protocol_agora_chat_group_manager_delegate-p.html#a51d07502e62c97e031cd3ab72366ebf3',1,'AgoraChatGroupManagerDelegate-p']]],
  ['joingrouprequestdiddecline_3areason_3adecliner_3aapplicant_3a_7',['joinGroupRequestDidDecline:reason:decliner:applicant:',['../protocol_agora_chat_group_manager_delegate-p.html#a767b859762ec255cb1218a5162c341b8',1,'AgoraChatGroupManagerDelegate-p']]],
  ['joingrouprequestdidreceive_3auser_3areason_3a_8',['joinGroupRequestDidReceive:user:reason:',['../protocol_agora_chat_group_manager_delegate-p.html#a439a794c621509ace77f2e4612cce9e7',1,'AgoraChatGroupManagerDelegate-p']]],
  ['joinpublicgroup_3acompletion_3a_9',['joinPublicGroup:completion:',['../protocol_i_agora_chat_group_manager-p.html#adfcff331d8c624b842dd88adfe7e91bb',1,'IAgoraChatGroupManager-p']]],
  ['joinpublicgroup_3aerror_3a_10',['joinPublicGroup:error:',['../protocol_i_agora_chat_group_manager-p.html#ae8a5f5db02410e01c6acd9501fa4065e',1,'IAgoraChatGroupManager-p']]]
];
