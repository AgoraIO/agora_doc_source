# VolumeContext

`VolumeContext` 提供音量管理相关能力。

## microphoneLevel

```typescript
microphoneLevel: number,
```

> 自 v1.1.2 起新增。

当前麦克风音量。取值范围为 0 到 20。